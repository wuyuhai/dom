/**
 * 树
 * @param obj	
 * 参数为对象，属性有：
	* - [必须] leftId：实例框的id。
	* - [必须] rightId：实例框的id。
	* - [必须] leftData：初始左边数据。
	* - [非必须] rightData：初始右边数据。
	* - [非必须]checkedIcon:"src/hadseck.png",//当点击样式为'checkbox',可传样式，勾选中的图标 默认为“src/hadseck”  可以不传
	* -	[非必须]disCheckedIcon:"src/noseck.png",//当点击样式为'checkbox',可传样式，没勾选中的图标 默认为“src/noseck”
	* var shuttleBox = new Jb_shuuule({
		leftId:"shuttleBoxLeft",
		rightId:"shuttleBoxRight",
		leftData:leftdata,
		// liClass:"cumclass",
		checkedIcon:"src/hadseck.png",//当点击样式为'checkbox',可传样式，勾选中的图标 默认为“src/hadseck”  可以不传
		disCheckedIcon:"src/noseck.png",//当点击样式为'checkbox',可传样式，没勾选中的图标 默认为“src/noseck”
	})
	$("#transrams").click(function(){					
		shuttleBox.transramsFun()
	})
	$("#saveDatas").click(function(){
		shuttleBox.thisSavedata()			
	})
	shuttleBox.saveData = function(a,b){
		console.log(a).
		console.log(b)
	}
	shuttleBox.unOrAnCheckCameBack = function(item,arr){
		console.log(item);
		console.log(arr);
	}
**/

function Jb_shuuule(obj){
	var obj = obj;
	var that = this;
	
	var leftData = obj.leftData;
	var rightData = obj.rightData?rightData:[];
	var liClass = obj.liClass?obj.liClass:"";
	var checkedIcon = obj.checkedIcon?obj.checkedIcon:"src/hadseck.png";
	var disCheckedIcon = obj.disCheckedIcon?obj.disCheckedIcon:"src/noseck.png";
	
	var mainBox = $("#" + obj.leftId);
	var shuttleBoxLeft = $("<div></div>")
	shuttleBoxLeft.addClass("shuttle-box-left")
	mainBox.append(shuttleBoxLeft)
	
	var viceBox = $("#" + obj.rightId);
	var shuttleBoxRight = $("<div></div>")
	shuttleBoxRight.addClass("shuttle-box-right")
	viceBox.append(shuttleBoxRight)
	
	function leftUlRendering(){
		var ul = $("<ul></ul>")		
		shuttleBoxLeft.append(ul)
		boxRendering(ul,leftData)
	}
	
	function rightUlRendering(){
		var ul = $("<ul></ul>")	
		shuttleBoxRight.append(ul)
	}
	
	function boxRendering(ul,data){
		ul.html("")
		for(var i = 0;i<data.length;i++){
			var li = $("<li></li>")
			li.attr("data-id",data[i].id)
			li.addClass(liClass);
			var div = $("<div></div>")
			div.addClass("check-div")
			var img = $("<img />")
			img.attr("src",disCheckedIcon)
			addEventHandler(img[0], "click", anCheck)
			div.append(img)			
			var span = $("<span><span/>")
			span.addClass("check-span")
			addEventHandler(span[0], "dblclick", addArr)
			span.html(data[i].name)
			li.append(div)
			li.append(span)
			ul.append(li)
		}
	}
	
	
	
	var temporaryArr = [];
	function addArr(){
		var mainUl = $("#" + obj.leftId + " ul");
		var viceUl = $("#" + obj.rightId + " ul");
		var t = this;
		if($(this).parents(".shuttle-box-left").length==1){
			leftData.forEach(function(item,idx){
				if(item.id == $(t).parent().attr("data-id")){
					leftData.splice(idx,1)
				}
			})
			rightData.push({
				id:$(t).parent().attr("data-id"),
				name:$(t).html()
			})
		}else{
			rightData.forEach(function(item,idx){				
				if(item.id == $(t).parent().attr("data-id")){
					rightData.splice(idx,1)
				}
			})
			leftData.push({
				id:$(t).parent().attr("data-id"),
				name:$(t).html()
			})
		}
		boxRendering(mainUl,leftData)
		boxRendering(viceUl,rightData)
	}
	
	function anCheck(){
		$(this).parent().append(checkedRender("yes"))
		var linode = $(this).parent().parent()
		var node = {
			id: linode.attr("data-id"),
			name: $(this).parent().next().html(),
		}
		temporaryArr.push(node)	
		that.unOrAnCheckCameBack(linode,temporaryArr)
		$(this).remove()
	}
	
	function unCheck(){
		$(this).parent().append(checkedRender("no"))
		var linode = $(this).parent().parent()
		for(var i = 0;i<temporaryArr.length;i++){
			if(temporaryArr[i].id == linode.attr("data-id")){
				temporaryArr.splice(i,1)
				that.unOrAnCheckCameBack(linode,temporaryArr)
				$(this).remove()
				return
			}
		}	

	}
	
	function checkedRender(kind){
		var img = $("<img />")
		if(kind == "yes"){
			img.attr("src",checkedIcon)
			addEventHandler(img[0], "click", unCheck)
		}else{
			img.attr("src",disCheckedIcon)
			addEventHandler(img[0], "click", anCheck)
			
		}	
		return img
	}
	
	function init(){
		leftUlRendering()
		rightUlRendering()
	}
	
	init()
	
	this.unOrAnCheckCameBack = function(item,arr){
		
	}
	
	this.transramsFun = function(){
		var mainUl = $("#" + obj.leftId + " ul");
		var viceUl = $("#" + obj.rightId + " ul");
		console.log(temporaryArr)
		temporaryArr.forEach(function(item,idx){
			var bol = false
			leftData.forEach(function(its,idy){
				if(item.id == its.id){
					leftData.splice(idy,1)
					bol = true
				}
			})
			if(bol == false){
				leftData.push(item)
			}
			var bol2 = false;
			rightData.forEach(function(its2,idz){
				if(item.id == its2.id){
					rightData.splice(idz,1)
					bol2 = true	
				}
			})
			if(bol2 == false){
				rightData.push(item)
			}					
		})
		boxRendering(mainUl,leftData)
		boxRendering(viceUl,rightData)
		temporaryArr = []
	}
	
	this.thisSavedata = function(){
		this.saveData(leftData,rightData)
	}
	
	this.saveData = function(a,b){
		
	}
}

//为新添加的元素节点添加点击事件
function addEventHandler(oTarget, sEventType, fnHandler) {
	if (oTarget.addEventListener) { //监听IE9，谷歌和火狐  
		oTarget.addEventListener(sEventType, fnHandler, false);
	} else if (oTarget.attachEvent) { //IE  
		oTarget.attachEvent("on" + sEventType, fnHandler);
	} else {
		oTarget["on" + sEventType] = fnHandler;
	}
}