/**
 * 页码组件
 * @param obj	
 * 参数为对象，属性有：
 * id ----- string
 * imgarr ------ 数组    图片数组对象{id,urls}
 * kind -------轮播类型  string ("yslider"Y轴方向滚动,"xslider"X轴方向滚动)
 * direction ------ 轮播方向  string ("x"X轴,"y"Y轴)
 * intervaltime ------ num   轮播间隔时间s
 * evelnum ------ 每组数量 num  
 * isShowspot ------ bol  是否显示上一张下一张滑块
 * isShowslider ------bol   是否显示轮播导航点
 * 
 * style
 * class
 * 
 * comeback
// var Slideshow = new Jb_slideshow({
// 	id:"slideshow",
// 	imgarr:imgarr,
// 	kind:"yslider",
// 	direction:"x",
// 	intervaltime:5000,
// 	isShowslider:true,
// 	isShowspot:true,
// 	evelnum:"2"
// })
 * ---------------------------- usage:----------------------------
 */
function Jb_slideshow(items){
	var obj = items;	
	var slideshow = $("#" + obj.id);
	var jbslideshow = $("<div></div>");
	jbslideshow.addClass("jb-slide-show");
	slideshow.append(jbslideshow)
	
	//渲染轮播盒子
	function slideBoxBendering(){
		var jbslideshowbox = $("<div></div>");
		jbslideshowbox.addClass("jb-slide-showbox");
		jbslideshow.append(jbslideshowbox);
		
		//根据轮播类型渲染滑动框
		var jbslideshowboxul =  $("<ul></ul>");
		jbslideshowboxul.addClass("jb-slide-showbox-ul");
		if(obj.direction == "x"){
			jbslideshowboxul.addClass("xslide");
		}
		if(obj.direction == "y"){
			jbslideshowboxul.addClass("yslide");
		}
		jbslideshowbox.append(jbslideshowboxul)
		slideLiRendering()
	}
	
	var nowslideliIndex = 0;
	function slideLiRendering(index){
		$("#" + obj.id + " .jb-slide-showbox-ul").html("")
		// console.log(index)
		if(index){
			nowslideliIndex = parseInt(index);
		}else{
			nowslideliIndex = 0;
		}	
		loadImgArr(nowslideliIndex)
	}
	//单个加载渲染图片资源
	var lengtgnum = 0;
	function loadImgArr(idx){
		// console.log(idx)
		var i;
		if(idx){
			i = idx;	
		}else{
			i = 0
		}	
		i = i - 1;
		if(i<0){
			i = obj.imgarr.length - 1
		}
		if(i>=obj.imgarr.length){
			i = 0
		}		
		var li = $("<li></li>");
		li.css({
			width:$("#" + obj.id)[0].clientWidth,
			height:$("#" + obj.id)[0].clientHeight,
		})
		var div = $("<div></div>");
		div.addClass("jb-slide-showbox-ul-center")
		div.attr("id",obj.imgarr[i].id);
		var img = new Image();
		img.src = obj.imgarr[i].urls;
		if(img.complete) {
			if((img.width/img.height)>($("#" + obj.id)[0].clientWidth/$("#" + obj.id)[0].clientHeight)){
				div.css({
					height:$("#" + obj.id)[0].clientWidth/(img.width/img.height),
					width:$("#" + obj.id)[0].clientWidth,
				})
			}else{		
				div.css({
					height:$("#" + obj.id)[0].clientHeight,
					width:$("#" + obj.id)[0].clientHeight/(img.height/img.width),
				})
			}
			div.html(img)
			li.append(div);		
			lengtgnum = lengtgnum + 1
			$("#" + obj.id + " .jb-slide-showbox-ul").append(li);
			if(lengtgnum>=3){
				if(obj.direction == "x"){
					$("#" + obj.id + " .jb-slide-showbox-ul").css({
						left:$("#" + obj.id)[0].clientWidth/2
					})
				}
				if(obj.direction == "y"){
					$("#" + obj.id + " .jb-slide-showbox-ul").css({
						top:$("#" + obj.id)[0].clientHeight/2
					})
				}
				return
			}	
			i = idx + 1; 
			loadImgArr(i)			
		}else{
			img.onload = function(){
				if((img.width/img.height)>($("#" + obj.id)[0].clientWidth/$("#" + obj.id)[0].clientHeight)){
					div.css({
						height:$("#" + obj.id)[0].clientWidth/(img.width/img.height),
						width:$("#" + obj.id)[0].clientWidth,
					})
				}else{		
					div.css({
						height:$("#" + obj.id)[0].clientHeight,
						width:$("#" + obj.id)[0].clientHeight/(img.height/img.width),
					})
				}
				div.html(img)
				li.append(div);		
				lengtgnum = lengtgnum + 1
				$("#" + obj.id + " .jb-slide-showbox-ul").append(li);	
				if(lengtgnum>=3){
					if(obj.direction == "x"){
						$("#" + obj.id + " .jb-slide-showbox-ul").css({
							left:$("#" + obj.id)[0].clientWidth/2
						})
					}
					if(obj.direction == "y"){
						$("#" + obj.id + " .jb-slide-showbox-ul").css({
							top:$("#" + obj.id)[0].clientHeight/2
						})
					}					
					return
				}	
				i = idx + 1; 
				loadImgArr(i)							
			}
		}	
	}
	
	//选择上一张下一张按钮
	function btnRendering(){
		var jbslideshowbtn = $("<div></div>");
		jbslideshowbtn.addClass("jb-slide-showbtn");
		
		$("#" + obj.id + " .jb-slide-show").append(jbslideshowbtn)
		var prevslideshowbtn = $("<div></div>");
		prevslideshowbtn.addClass("prev-slide-showbtn");
		addEventHandler(prevslideshowbtn[0], 'click', prevpage);
			
		var nextslideshowbtn = $("<div></div>");
		nextslideshowbtn.addClass("next-slide-showbtn");
		addEventHandler(nextslideshowbtn[0], 'click', nextpage);
		
		if(obj.direction == "x"){
			jbslideshowbtn.addClass("jb-slide-showbtn-x")
			prevslideshowbtn.html("<")
			prevslideshowbtn.addClass("prev-slide-showbtn-x");
			nextslideshowbtn.html(">")
			nextslideshowbtn.addClass("next-slide-showbtn-x");
		}
		
		if(obj.direction == "y"){
			jbslideshowbtn.addClass("jb-slide-showbtn-y")
			prevslideshowbtn.html("prev")
			prevslideshowbtn.addClass("prev-slide-showbtn-y");
			nextslideshowbtn.html("next")
			nextslideshowbtn.addClass("next-slide-showbtn-y");
		}
		
		jbslideshowbtn.append(prevslideshowbtn)
		jbslideshowbtn.append(nextslideshowbtn)
	}
	
	function spotRender(){
		var jbslideshowspolt = $("<div></div>");
		jbslideshowspolt.addClass("jb-slide-show-spolt");
		if(obj.direction == "x"){
			jbslideshowspolt.addClass("jb-slide-show-spolt-x");
		}
		if(obj.direction == "y"){
			jbslideshowspolt.addClass("jb-slide-show-spolt-y");
		}
		var ul = $("<ul></ul>"); 
		for(var i = 0;i<obj.imgarr.length;i++){
			var li = $("<li></li>"); 
			li.attr("data-num",i)
			if(i == nowslideliIndex){
				li.addClass("cur")								
			}
			addEventHandler(li[0], 'click', spotClick);
			ul.append(li)
		}
		jbslideshowspolt.append(ul)
		$("#" + obj.id + " .jb-slide-show").append(jbslideshowspolt)
	}
	
	var jyorder = "next"
	function prevpage(){
		clearTimeout(intervaltimeslider)
		jyorder = "prev";
		sliderNum("prev")
	}
	
	function nextpage(){
		clearTimeout(intervaltimeslider)
		jyorder = "next"
		sliderNum("next")
	}
	
	function synchronizationSpolt(idx){
		var spoltarr = $("#" + obj.id + " .jb-slide-show-spolt").find("li");
		for(var i = 0;i<spoltarr.length;i++){
			$(spoltarr[i]).removeClass("cur")
			if($(spoltarr[i]).attr("data-num") == idx){
				$(spoltarr[i]).addClass("cur")
			}
		}
	}
	
	function spotClick(){	
		$(this).siblings().removeClass("cur");
		$(this).addClass("cur")	
		clearTimeout(intervaltimeslider)
		$("#" + obj.id + " .jb-slide-showbox-ul").find("li")
		console.log($("#" + obj.id + " .jb-slide-showbox-ul").find("li"))
		var noli = ""
		if(jyorder == "prev"){		
			noli = $($("#" + obj.id + " .jb-slide-showbox-ul").find("li")[0]);			
		}
		if(jyorder == "next"){
			noli = $($("#" + obj.id + " .jb-slide-showbox-ul").find("li")[2])			
		}
		noli.html("");
		var div = $("<div></div>");
		div.addClass("jb-slide-showbox-ul-center")
		div.attr("id",$(this).attr("data-num"));
		var img = new Image();
		img.src = obj.imgarr[$(this).attr("data-num")].urls;
		if(img.complete){
			if((img.width/img.height)>($("#" + obj.id)[0].clientWidth/$("#" + obj.id)[0].clientHeight)){
				div.css({
					height:$("#" + obj.id)[0].clientWidth/(img.width/img.height),
					width:$("#" + obj.id)[0].clientWidth,
				})
			}else{		
				div.css({
					height:$("#" + obj.id)[0].clientHeight,
					width:$("#" + obj.id)[0].clientHeight/(img.height/img.width),
				})
			}
			div.html(img)
			noli.append(div)
			nowslideliIndex = $(this).attr("data-num");
			console.log(nowslideliIndex)
			sliderNum("spot")
		}else{
			img.onload = function(){
				if((img.width/img.height)>($("#" + obj.id)[0].clientWidth/$("#" + obj.id)[0].clientHeight)){
					div.css({
						height:$("#" + obj.id)[0].clientWidth/(img.width/img.height),
						width:$("#" + obj.id)[0].clientWidth,
					})
				}else{		
					div.css({
						height:$("#" + obj.id)[0].clientHeight,
						width:$("#" + obj.id)[0].clientHeight/(img.height/img.width),
					})
				}
				div.html(img)
				noli.append(div)
				nowslideliIndex = $(this).attr("data-num");
				console.log(nowslideliIndex)
				sliderNum("spot")
			}			
		}
	}
		
	var slidernumtime;
	function sliderNum(kind){
		clearInterval(slidernumtime)						
		if(kind == "spot"){
			console.log(nowslideliIndex)
		}else{
			if(jyorder == "prev"){
				nowslideliIndex = nowslideliIndex - 1;
				if(nowslideliIndex<0){
					nowslideliIndex = obj.imgarr.length-1
				}
			}
			if(jyorder == "next"){
				nowslideliIndex = nowslideliIndex + 1;
				if(nowslideliIndex>obj.imgarr.length-1){
					nowslideliIndex = 0
				}
			}
		}
		synchronizationSpolt(nowslideliIndex)
		var snum = 0
		slidernumtime = setInterval(function(){
			if(jyorder == "prev"){
				snum += 5;
			}
			if(jyorder == "next"){
				snum -= 5;
			}	
			
			var maxnum = $("#" + obj.id)[0].clientWidth
			if(obj.direction == "x"){
				$("#" + obj.id + " .jb-slide-showbox-ul").css({
					left:$("#" + obj.id)[0].clientWidth/2 + snum
				})
				maxnum = $("#" + obj.id)[0].clientWidth;
			}
			if(obj.direction == "y"){
				$("#" + obj.id + " .jb-slide-showbox-ul").css({
					top:$("#" + obj.id)[0].clientHeight/2 + snum
				})
				maxnum = $("#" + obj.id)[0].clientHeight
			}
			if(Math.abs(snum) >= maxnum){	
				clearInterval(slidernumtime);
				lengtgnum = 0				
				slideLiRendering(nowslideliIndex)
				clearTimeout(intervaltimeslider)	
						
				intervaltimeslider = setTimeout(function(){
					sliderNum(jyorder)	
				},intervaltime)
			}
		},2)
	}
	
	var intervaltimeslider;
	var intervaltime = obj.intervaltime?obj.intervaltime:5000;
	
	$("#" + obj.id).mouseenter(function(){
		if(intervaltimeslider){
			clearTimeout(intervaltimeslider)
		}
	})
	
	$("#" + obj.id).mouseout(function(){
		if(obj.intervaltime){
			intervaltimeslider = setTimeout(function(){
				sliderNum(jyorder)	
			},intervaltime)	
		}	
	})
	
	this.init = function(){
		slideBoxBendering()
		if(obj.isShowslider == true){
			btnRendering()
		}
		if(obj.isShowspot == true){
			spotRender()
		}
		if(obj.intervaltime){
			intervaltimeslider = setTimeout(function(){
				nextpage()
			},intervaltime)	
		}
	}
	this.comeback = function(){
		
	};
}

var imgarr = [{
	id:0,
	urls:"src/imgs/0.jpg",
},{
	id:1,
	urls:"src/imgs/1.jpg",
},{
	id:2,
	urls:"src/imgs/2.jpg",
},{
	id:3,
	urls:"src/imgs/3.jpg",
},{
	id:4,
	urls:"src/imgs/4.jpg",
},{
	id:5,
	urls:"src/imgs/5.jpg",
},
// {
// 	id:6,
// 	urls:"src/imgs/6.jpg",
// },{
// 	id:7,
// 	urls:"src/imgs/7.jpg",
// },{
// 	id:8,
// 	urls:"src/imgs/8.jpg",
// },{
// 	id:9,
// 	urls:"src/imgs/9.jpg",
// },{
// 	id:10,
// 	urls:"src/imgs/10.jpg",
// },{
// 	id:11,
// 	urls:"src/imgs/11.jpg",
// },
];

var Slideshow = new Jb_slideshow({
	id:"slideshow",
	imgarr:imgarr,
	kind:"yslider",
	direction:"x",
	intervaltime:5000,
	isShowslider:true,
	isShowspot:true,
	evelnum:"2"
})
Slideshow.init();

// Slideshow.comeback = function(t){
// 	console.log("1")
// }