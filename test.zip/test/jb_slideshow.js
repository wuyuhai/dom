/**
 * 页码组件
 * @param obj	
 * 参数为对象，属性有：
 * id ----- string
 * imgarr ------ 数组
 * kind -------轮播类型  string
 * direction ------ 轮播方向  string
 * intervaltime ------ num
 * evelnum ------ 每组数量 num
 * isShowspot ------ bol
 * isShowslider ------bol
 * style
 * class
 * 方法有：
 * 上一页
 * 下一页
 * 选择页
 * 跳转页
 * 重新分页
 * comeback
var npage = new Jb_slideshow({
 	
 })
 * ---------------------------- usage:----------------------------
 */
function Jb_slideshow(items){
	var obj = items;	
	var slideshow = $("#" + obj.id);
	var jbslideshow = $("<div></div>");
	jbslideshow.addClass("jbslideshow");
	slideshow.append(jbslideshow)
	
	//渲染轮播盒子
	function slideboxrendering(){
		var jbslideshowbox = $("<div></div>");
		jbslideshowbox.addClass("jbslideshowbox");
		jbslideshow.append(jbslideshowbox);
		
		//根据轮播类型渲染滑动框
		var jbslideshowboxul =  $("<ul></ul>");
		jbslideshowboxul.addClass("jbslideshowboxul");
		if(obj.direction == "x"){
			jbslideshowboxul.addClass("xslide");
		}
		if(obj.direction == "y"){
			jbslideshowboxul.addClass("yslide");
		}
		jbslideshowbox.append(jbslideshowboxul)
		slidelirendering()
	}
	
	var nowslideliIndex = 0;
	function slidelirendering(index){
		$("#" + obj.id + " .jbslideshowboxul").html("")
		// console.log(index)
		if(index){
			nowslideliIndex = parseInt(index);
		}else{
			nowslideliIndex = 0;
		}	
		loadimgarr(nowslideliIndex)
	}
	//单个加载渲染图片资源
	var lengtgnum = 0;
	function loadimgarr(idx){
		// console.log(idx)
		var i;
		if(idx){
			i = idx;	
		}else{
			i = 0
		}	
		i = i - 1;
		if(i<0){
			i = obj.imgarr.length - 1
		}
		if(i>=obj.imgarr.length){
			i = 0
		}		
		var li = $("<li></li>");
		li.css({
			width:$("#" + obj.id)[0].clientWidth,
			height:$("#" + obj.id)[0].clientHeight,
		})
		var div = $("<div></div>");
		div.addClass("jbslideshowboxul_center")
		div.attr("id",obj.imgarr[i].id);
		var img = new Image();
		img.src = obj.imgarr[i].urls;
		if(img.complete) {
			if((img.width/img.height)>($("#" + obj.id)[0].clientWidth/$("#" + obj.id)[0].clientHeight)){
				div.css({
					height:$("#" + obj.id)[0].clientWidth/(img.width/img.height),
					width:$("#" + obj.id)[0].clientWidth,
				})
			}else{		
				div.css({
					height:$("#" + obj.id)[0].clientHeight,
					width:$("#" + obj.id)[0].clientHeight/(img.height/img.width),
				})
			}
			div.html(img)
			li.append(div);		
			lengtgnum = lengtgnum + 1
			$("#" + obj.id + " .jbslideshowboxul").append(li);
			if(lengtgnum>=3){
				if(obj.direction == "x"){
					$("#" + obj.id + " .jbslideshowboxul").css({
						left:$("#" + obj.id)[0].clientWidth/2
					})
				}
				if(obj.direction == "y"){
					$("#" + obj.id + " .jbslideshowboxul").css({
						top:$("#" + obj.id)[0].clientHeight/2
					})
				}
				return
			}	
			i = idx + 1; 
			loadimgarr(i)			
		}else{
			img.onload = function(){
				if((img.width/img.height)>($("#" + obj.id)[0].clientWidth/$("#" + obj.id)[0].clientHeight)){
					div.css({
						height:$("#" + obj.id)[0].clientWidth/(img.width/img.height),
						width:$("#" + obj.id)[0].clientWidth,
					})
				}else{		
					div.css({
						height:$("#" + obj.id)[0].clientHeight,
						width:$("#" + obj.id)[0].clientHeight/(img.height/img.width),
					})
				}
				div.html(img)
				li.append(div);		
				lengtgnum = lengtgnum + 1
				$("#" + obj.id + " .jbslideshowboxul").append(li);	
				if(lengtgnum>=3){
					if(obj.direction == "x"){
						$("#" + obj.id + " .jbslideshowboxul").css({
							left:$("#" + obj.id)[0].clientWidth/2
						})
					}
					if(obj.direction == "y"){
						$("#" + obj.id + " .jbslideshowboxul").css({
							top:$("#" + obj.id)[0].clientHeight/2
						})
					}					
					return
				}	
				i = idx + 1; 
				loadimgarr(i)							
			}
		}	
	}
	
	//选择上一张下一张按钮
	function btnrendering(){
		var jbslideshowbtn = $("<div></div>");
		jbslideshowbtn.addClass("jbslideshowbtn");
		
		$("#" + obj.id + " .jbslideshow").append(jbslideshowbtn)
		var prevslideshowbtn = $("<div></div>");
		prevslideshowbtn.addClass("prevslideshowbtn");
		addEventHandler(prevslideshowbtn[0], 'click', prevpage);
			
		var nextslideshowbtn = $("<div></div>");
		nextslideshowbtn.addClass("nextslideshowbtn");
		htmlscont.append(div)
		
		if(obj.direction == "x"){
			jbslideshowbtn.addClass("jbslideshowbtn_x")
			prevslideshowbtn.html("<")
			prevslideshowbtn.addClass("prevslideshowbtn_x");
			nextslideshowbtn.html(">")
			nextslideshowbtn.addClass("nextslideshowbtn_x");
		}
		
		if(obj.direction == "y"){
			jbslideshowbtn.addClass("jbslideshowbtn_y")
			prevslideshowbtn.html("prev")
			prevslideshowbtn.addClass("prevslideshowbtn_y");
			nextslideshowbtn.html("next")
			nextslideshowbtn.addClass("nextslideshowbtn_y");
		}
		
		jbslideshowbtn.append(prevslideshowbtn)
		jbslideshowbtn.append(nextslideshowbtn)
	}
	
	function spotrender(){
		var jbslideshowspolt = $("<div></div>");
		jbslideshowspolt.addClass("jbslideshowspolt");
		if(obj.direction == "x"){
			jbslideshowspolt.addClass("jbslideshowspolt_x");
		}
		if(obj.direction == "y"){
			jbslideshowspolt.addClass("jbslideshowspolt_y");
		}
		var ul = $("<ul></ul>"); 
		for(var i = 0;i<obj.imgarr.length;i++){
			var li = $("<li></li>"); 
			li.attr("data-num",i)
			if(i == nowslideliIndex){
				li.addClass("cur")								
			}
			addEventHandler(li[0], 'click', spotclick);
			ul.append(li)
		}
		jbslideshowspolt.append(ul)
		$("#" + obj.id + " .jbslideshow").append(jbslideshowspolt)
	}
	
	var jyorder = "next"
	function prevpage(){
		clearTimeout(intervaltimeslider)
		jyorder = "prev";
		slidernum("prev")
	}
	
	function nextpage(){
		clearTimeout(intervaltimeslider)
		jyorder = "next"
		slidernum("next")
	}
	
	function synchronizationspolt(idx){
		var spoltarr = $("#" + obj.id + " .jbslideshowspolt").find("li");
		for(var i = 0;i<spoltarr.length;i++){
			$(spoltarr[i]).removeClass("cur")
			if($(spoltarr[i]).attr("data-num") == idx){
				$(spoltarr[i]).addClass("cur")
			}
		}
	}
	
	function spotclick(){	
		$(this).siblings().removeClass("cur");
		$(this).addClass("cur")	
		clearTimeout(intervaltimeslider)
		$("#" + obj.id + " .jbslideshowboxul").find("li")
		console.log($("#" + obj.id + " .jbslideshowboxul").find("li"))
		var noli = ""
		if(jyorder == "prev"){		
			noli = $($("#" + obj.id + " .jbslideshowboxul").find("li")[0]);			
		}
		if(jyorder == "next"){
			noli = $($("#" + obj.id + " .jbslideshowboxul").find("li")[2])			
		}
		noli.html("");
		var div = $("<div></div>");
		div.addClass("jbslideshowboxul_center")
		div.attr("id",$(this).attr("data-num"));
		var img = new Image();
		img.src = obj.imgarr[$(this).attr("data-num")].urls;
		if(img.complete){
			if((img.width/img.height)>($("#" + obj.id)[0].clientWidth/$("#" + obj.id)[0].clientHeight)){
				div.css({
					height:$("#" + obj.id)[0].clientWidth/(img.width/img.height),
					width:$("#" + obj.id)[0].clientWidth,
				})
			}else{		
				div.css({
					height:$("#" + obj.id)[0].clientHeight,
					width:$("#" + obj.id)[0].clientHeight/(img.height/img.width),
				})
			}
			div.html(img)
			noli.append(div)
			nowslideliIndex = $(this).attr("data-num");
			console.log(nowslideliIndex)
			slidernum("spot")
		}else{
			img.onload = function(){
				if((img.width/img.height)>($("#" + obj.id)[0].clientWidth/$("#" + obj.id)[0].clientHeight)){
					div.css({
						height:$("#" + obj.id)[0].clientWidth/(img.width/img.height),
						width:$("#" + obj.id)[0].clientWidth,
					})
				}else{		
					div.css({
						height:$("#" + obj.id)[0].clientHeight,
						width:$("#" + obj.id)[0].clientHeight/(img.height/img.width),
					})
				}
				div.html(img)
				noli.append(div)
				nowslideliIndex = $(this).attr("data-num");
				console.log(nowslideliIndex)
				slidernum("spot")
			}			
		}
	}
		
	var slidernumtime;
	function slidernum(kind){
		console.log(1)
		clearInterval(slidernumtime)						
		if(kind == "spot"){
			console.log(nowslideliIndex)
		}else{
			if(jyorder == "prev"){
				nowslideliIndex = nowslideliIndex - 1;
				if(nowslideliIndex<0){
					nowslideliIndex = obj.imgarr.length-1
				}
			}
			if(jyorder == "next"){
				nowslideliIndex = nowslideliIndex + 1;
				if(nowslideliIndex>obj.imgarr.length-1){
					nowslideliIndex = 0
				}
			}
		}
		synchronizationspolt(nowslideliIndex)
		var snum = 0
		slidernumtime = setInterval(function(){
			if(jyorder == "prev"){
				snum += 5;
			}
			if(jyorder == "next"){
				snum -= 5;
			}	
			
			var maxnum = $("#" + obj.id)[0].clientWidth
			if(obj.direction == "x"){
				$("#" + obj.id + " .jbslideshowboxul").css({
					left:$("#" + obj.id)[0].clientWidth/2 + snum
				})
				maxnum = $("#" + obj.id)[0].clientWidth;
			}
			if(obj.direction == "y"){
				$("#" + obj.id + " .jbslideshowboxul").css({
					top:$("#" + obj.id)[0].clientHeight/2 + snum
				})
				maxnum = $("#" + obj.id)[0].clientHeight
			}
			if(Math.abs(snum) >= maxnum){	
				clearInterval(slidernumtime);
				lengtgnum = 0				
				slidelirendering(nowslideliIndex)
				clearTimeout(intervaltimeslider)	
						
				intervaltimeslider = setTimeout(function(){
					slidernum(jyorder)	
				},intervaltime)
			}
		},2)
	}
	
	var intervaltimeslider;
	var intervaltime = obj.intervaltime?obj.intervaltime:5000;
	
	this.init = function(){
		slideboxrendering()
		if(obj.isShowslider == true){
			btnrendering()
		}
		if(obj.isShowspot == true){
			spotrender()
		}
		intervaltimeslider = setTimeout(function(){
			nextpage()
		},intervaltime)	
	}
	this.comeback = function(){
		
	};
}

var imgarr = [{
	id:0,
	urls:"src/imgs/0.jpg",
},{
	id:1,
	urls:"src/imgs/1.jpg",
},{
	id:2,
	urls:"src/imgs/2.jpg",
},{
	id:3,
	urls:"src/imgs/3.jpg",
},{
	id:4,
	urls:"src/imgs/4.jpg",
},{
	id:5,
	urls:"src/imgs/5.jpg",
},
// {
// 	id:6,
// 	urls:"src/imgs/6.jpg",
// },{
// 	id:7,
// 	urls:"src/imgs/7.jpg",
// },{
// 	id:8,
// 	urls:"src/imgs/8.jpg",
// },{
// 	id:9,
// 	urls:"src/imgs/9.jpg",
// },{
// 	id:10,
// 	urls:"src/imgs/10.jpg",
// },{
// 	id:11,
// 	urls:"src/imgs/11.jpg",
// },
];

// var Slideshow = new Jb_slideshow({
// 	id:"slideshow",
// 	imgarr:imgarr,
// 	kind:"yslider",
// 	direction:"x",
// 	intervaltime:5000,
// 	isShowslider:true,
// 	isShowspot:true,
// 	evelnum:"2"
// })
// Slideshow.init();

// Slideshow.comeback = function(t){
// 	console.log("1")
// }