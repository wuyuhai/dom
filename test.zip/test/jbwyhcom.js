/**
 * 时间组件
 * @param obj	
 * 参数为对象，属性有：
 * id (必填)
 * kind: "time","date","datetime","year","month","dateRange","timeRange","yearRange","monthRange","datetimeRange"，(必填)
 * date:"初始化时间" (非必填)
 * style
 * class
 * 方法有：
 * 上一年
 * 下一年
 * 上一月
 * 下一月
 * 日期选择
 * var newDate = new Jbdate({
	id:"jbdate"
});
 * ---------------------------- usage:----------------------------
 */
function Jbdate(date) {	
	console.log(date)
	var obj = date
	this.id = date.id;
	this.dateble = [];	
	
	var datefun = $("#" + date.id);
	var datebox = $("<div></div>");	
	if(obj.kind.indexOf("Range") != -1){
		datebox.addClass("datebox-range")
	}else{
		datebox.addClass("datebox")
	}	
	datefun.append(datebox)
	
	var getdates = obj.date
	var dates = new Date(getdates);
	var year = dates.getFullYear()
	var yue = (dates.getMonth() + 1)>=10?(dates.getMonth() + 1):("0" + (dates.getMonth() + 1));
	var yues = dates.getMonth() + 1
	var day = dates.getDate()>=10?dates.getDate():("0" + dates.getDate());
	var h = dates.getHours()
	var m = dates.getMinutes()
	var s = dates.getSeconds()
	
	function nowTimeDay(){						
		var xq = ["天","一","二","三","四","五","六"]
		this.time = year + "-" + yue +  "-" + day + " 星期" + xq[dates.getDay()]
		return this.time;
	}
	
	function tableEle(pcontclass){
		var alldays = new Date(year,yues,0).getDate();
		var nowday = new Date(year + "-" + yue + "-" + "01").getDay();
		var dateble = {
			tr:[{
				td:[],
			},{
				td:[],
			},{
				td:[],
			},{
				td:[],
			},{
				td:[],
			},{
				td:[],
			}],
		}	
		// console.log(alldays,nowday)
		var cur = []				
		for(var i = 0;i<alldays + nowday;i++){
			if(i>=nowday){
				if(cur[i-nowday] == i-nowday+1){
					dateble.tr[parseInt(i/7)].td.push({
						n:i-nowday+1,
						cur:1
					})
				}else{
					dateble.tr[parseInt(i/7)].td.push({
						n:i-nowday+1,
					})
				}
			}else{
				dateble.tr[parseInt(i/7)].td.push({
					n:"",
				})
			}
		}
		this.dateble = dateble;
		rtableRendering(pcontclass)
	}

	function headRending(){
		var databoxhead = $("<div></div>");	
		databoxhead.addClass("databox-head");				
		datebox.append(databoxhead)
		headRendingKind();
	}
	
	//渲染头 kind种类'normol','onyear','onmonth'
	function headRendingKind(kind){
		var databoxhead = $(".databox-head");
		databoxhead.html("")
		var rangedivl,rangedivr;
		rangedivl = $("<div></div>");
		rangedivl.addClass("range-div-l")
		rangedivr = $("<div></div>");
		rangedivr.addClass("range-div-r")
		
		if(obj.kind.indexOf("Range")!=-1){
			databoxhead.append(rangedivl)
			databoxhead.append(rangedivr)
		}
		headRendingKindTwo(kind)
	}
	function headRendingKindTwo(kind,txt){		
		var databoxhead = $(".databox-head");
		var rangedivl = $(".range-div-l");
		var rangedivr = $(".range-div-r");
		
		//一般情况渲染head
		var preyear,premonth,nowyear,nowmonth,nextmonth,nextyear,onyear;		
		preyear = $("<span></span>");		
		premonth = $("<span></span>");		
		nowyear = $("<span></span>");		
		nowmonth = $("<span></span>");	
		nextmonth = $("<span></span>");		
		nextyear = $("<span></span>");
		onyear = $("<span></span>");		
		
		//根据实列情况添加head元素和类名
		preyear.addClass("preyear")
		preyear.html("<<")
		addEventHandler(preyear[0], 'click', yearbind);
			
		premonth.addClass("premonth")
		premonth.html("<")
		addEventHandler(premonth[0], 'click', monthbind);
			
		nowyear.addClass("nowyear")
		nowyear.html(year + "年")	
		addEventHandler(nowyear[0], 'click', yearbind);
		
		nowmonth.addClass("nowmonth")
		nowmonth.html(yue + "月")
		addEventHandler(nowmonth[0], 'click', monthbind);
		
		nextmonth.addClass("nextmonth")
		nextmonth.html(">")
		addEventHandler(nextmonth[0], 'click', monthbind);
		
		nextyear.addClass("nextyear")
		nextyear.html(">>")
		addEventHandler(nextyear[0], 'click', yearbind);
			
		onyear.addClass("onyear")
		// addEventHandler(onyear[0], 'click', yearLiClickBind);
		
		//选择类型为范围选择时
		var preyearRange,preyearRangeTwo,premonthRange,nowyearRange,nowyearRangeTwo,nowmonthRange,
		nowmonthRangeTwo,nextmonthRange,nextyearRange,nextyearRangeTwo,onyearRange,onyearRangeTwo;
			
		preyearRange = $("<span></span>");
		preyearRangeTwo = $("<span></span>");
		premonthRange = $("<span></span>");
		nowyearRange = $("<span></span>");	
		nowyearRangeTwo = $("<span></span>");
		nowmonthRange = $("<span></span>");					
		nowmonthRangeTwo = $("<span></span>");	
		nextmonthRange = $("<span></span>");			
		nextyearRange = $("<span></span>");
		nextyearRangeTwo = $("<span></span>");
		onyearRange = $("<span></span>");	
		onyearRangeTwo = $("<span></span>");
			
		preyearRange.addClass("preyear-range")
		preyearRange.addClass("preyear")
		preyearRange.html("<<")
				
		preyearRangeTwo.addClass("preyear-range-two")
		preyearRangeTwo.addClass("preyear")
		preyearRangeTwo.html("<<")
		
		premonthRange.addClass("premonth-range")
		premonthRange.addClass("premonth")
		premonthRange.html("<")		
		
		nowyearRange.addClass("nowyear-range")
		nowyearRange.addClass("nowyear")
		
		nowyearRangeTwo.addClass("nowyear-range-two")
		nowyearRangeTwo.addClass("nowyear")
		
		nowmonthRange.addClass("nowmonth-range")
		nowmonthRange.addClass("nowmonth")
		
		nowmonthRangeTwo.addClass("nowmonth-range-two")
		nowmonthRangeTwo.addClass("nowmonth")		
		
		nextmonthRange.addClass("nextmonth-range")
		nextmonthRange.addClass("nextmonth")
		nextmonthRange.html(">")	
		
		
		nextyearRange.addClass("nextyear-range")
		nextyearRange.addClass("nextyear")
		nextyearRange.html(">>")	
		
		nextyearRangeTwo.addClass("nextyear-range-two")
		nextyearRangeTwo.addClass("nextyear")
		nextyearRangeTwo.html(">>")
		
		
		onyearRange.addClass("onyear")
		onyearRange.addClass("onyear-range")
		// addEventHandler(onyearRange[0], 'click', monthbind);
		
		onyearRangeTwo.addClass("onyear")
		onyearRangeTwo.addClass("onyear-range-two")
		// addEventHandler(onyearRangeTwo[0], 'click', monthbind);
								
		if(!kind){
			kind = "normol";
			switch(obj.kind){
			    case "time":
					kind = "select-time"
			        break;
			    case "year":
					kind = "year"
			        break;
				case "month":
					kind = "month"
				    break;	
				case "yearRange":
					kind = "yearRange"
				    break;
				case "monthRange":
					kind = "monthRange"
				    break;	
				case "dateRange":
					kind = "dateRange"
				    break;	
				case "timeRange":
					kind = "timeRange"
				    break;	
				case "datetimeRange":
					kind = "datetimeRange"
				    break;	
			    default:
			        console.log("种类未定义")
			}
		}else{
			kind = kind;
		}
		switch(kind){
		    case "normol":
				databoxhead.append(preyear);
				databoxhead.append(premonth);
				databoxhead.append(nowyear);
				databoxhead.append(nowmonth);
				databoxhead.append(nextmonth);
				databoxhead.append(nextyear);
		        break;
		    case "onyear":
				onyear.html((year-7) + "年-" + (year+7) + "年")
				databoxhead.append(preyear);
		        databoxhead.append(onyear)
				databoxhead.append(nextyear);
		        break;
			case "onmonth":
				onyear.html(year+ "年")
				databoxhead.append(premonth);
			    databoxhead.append(onyear)
				databoxhead.append(nextmonth);
			    break;	
			case "year":
				onyear.html((year-7) + "年-" + (year+7) + "年")
				databoxhead.append(preyear);
				databoxhead.append(onyear)
				databoxhead.append(nextyear);	
				 break;	
			case "month":
				onyear.html(year+ "年")
				databoxhead.append(premonth);
				databoxhead.append(onyear)
				databoxhead.append(nextmonth);
				break;		
			case "select-time":
				onyear.html("选择时间")
			    databoxhead.append(onyear)
			    break;	
			case "yearRange":
				onyearRange.html((year-7) + "年-" + (year+7) + "年")
				onyearRangeTwo.html((year-6) + "年-" + (year+8) + "年")
				
				addEventHandler(preyearRange[0], 'click', yearbind);
				addEventHandler(preyearRangeTwo[0], 'click', yearbind);
				addEventHandler(nextyearRangeTwo[0], 'click', yearbind);
				addEventHandler(nextyearRange[0], 'click', yearbind);
				
				rangedivl.append(preyearRange)
				rangedivl.append(onyearRange)
				rangedivl.append(nextyearRange)
				
				rangedivr.append(preyearRangeTwo)
				rangedivr.append(onyearRangeTwo)
				rangedivr.append(nextyearRangeTwo)
			    break;	
			case "monthRange":
				onyearRange.html(year + "年")
				onyearRangeTwo.html(year + "年")
				
				addEventHandler(preyearRange[0], 'click', monthbind);
				addEventHandler(preyearRangeTwo[0], 'click', monthbind);
				addEventHandler(nextyearRangeTwo[0], 'click', monthbind);
				addEventHandler(nextyearRange[0], 'click', monthbind);
				
				rangedivl.append(preyearRange)
				rangedivl.append(onyearRange)
				rangedivl.append(nextyearRange)
				
				rangedivr.append(preyearRangeTwo)
				rangedivr.append(onyearRangeTwo)
				rangedivr.append(nextyearRangeTwo)	
				break;	
			case "timeRange":
				onyearRange.html("选择时间")
				onyearRangeTwo.html("选择时间")
				
				rangedivl.append(onyearRange)
				rangedivr.append(onyearRangeTwo)	
				break;	
			case "dateRange":							
				nowyearRange.html(year + "年")
				nowmonthRange.html(yue + "月")
				rangedivl.append(preyearRange)
				rangedivl.append(premonthRange)				
				rangedivl.append(nowyearRange)
				rangedivl.append(nowmonthRange)
				if(yues+1>12){
					nowyearRangeTwo.html((year+1) + "年")
					nowmonthRangeTwo.html("01" + "月")
				}else{
					var myaer = (yues+1)>=10?(yues+1):("0"+(yues+1))
					nowyearRangeTwo.html(year + "年")
					nowmonthRangeTwo.html(myaer + "月")
				}
							
				rangedivr.append(nowyearRangeTwo)
				rangedivr.append(nowmonthRangeTwo)
				rangedivr.append(nextmonthRange)
				rangedivr.append(nextyearRange)
				
				addEventHandler(preyearRange[0], 'click', rangeYearBind);										
				addEventHandler(premonthRange[0], 'click', rangeYearBind);
				addEventHandler(nextmonthRange[0], 'click', rangeYearBind);				
				addEventHandler(nextyearRange[0], 'click', rangeYearBind);
				addEventHandler(nowyearRange[0], 'click', rangeYearBind);
				addEventHandler(nowyearRangeTwo[0], 'click', rangeYearBind);
				addEventHandler(nowmonthRange[0], 'click', rangeYearBind);
				addEventHandler(nowmonthRangeTwo[0], 'click', rangeYearBind);	
				break;
			case "datetimeRange":
				nowyearRange.html(year + "年")
				nowmonthRange.html(yue + "月")
				rangedivl.append(preyearRange)
				rangedivl.append(premonthRange)				
				rangedivl.append(nowyearRange)
				rangedivl.append(nowmonthRange)
				if(yues+1>12){
					nowyearRangeTwo.html((year+1) + "年")
					nowmonthRangeTwo.html("01" + "月")
				}else{
					var myaer = (yues+1)>=10?(yues+1):("0"+(yues+1))
					nowyearRangeTwo.html(year + "年")
					nowmonthRangeTwo.html(myaer + "月")
				}
							
				rangedivr.append(nowyearRangeTwo)
				rangedivr.append(nowmonthRangeTwo)
				rangedivr.append(nextmonthRange)
				rangedivr.append(nextyearRange)
				
				addEventHandler(preyearRange[0], 'click', rangeYearBind);										
				addEventHandler(premonthRange[0], 'click', rangeYearBind);
				addEventHandler(nextmonthRange[0], 'click', rangeYearBind);				
				addEventHandler(nextyearRange[0], 'click', rangeYearBind);
				addEventHandler(nowyearRange[0], 'click', rangeYearBind);
				addEventHandler(nowyearRangeTwo[0], 'click', rangeYearBind);
				addEventHandler(nowmonthRange[0], 'click', rangeYearBind);
				addEventHandler(nowmonthRangeTwo[0], 'click', rangeYearBind);	
				break;			
			case "dateRangeyearl":
				onyearRange.html(txt)
				rangedivl.append(preyearRange)			
				rangedivl.append(onyearRange)
				rangedivl.append(nextyearRange)
										
				addEventHandler(preyearRange[0], 'click', rangeYearBinds);										
				addEventHandler(nextyearRange[0], 'click', rangeYearBinds);	
				break;	
			case "dateRangeyearr":
				onyearRangeTwo.html(txt)
				rangedivr.append(preyearRangeTwo)			
				rangedivr.append(onyearRangeTwo)
				rangedivr.append(nextyearRangeTwo)
										
				addEventHandler(preyearRangeTwo[0], 'click', rangeYearBinds);										
				addEventHandler(nextyearRangeTwo[0], 'click', rangeYearBinds);	
				break;	
			case "dateRangemonthl":
				onyearRangeTwo.html(txt)
				rangedivl.append(preyearRangeTwo)			
				rangedivl.append(onyearRangeTwo)
				rangedivl.append(nextyearRangeTwo)
										
				addEventHandler(preyearRangeTwo[0], 'click', rangeYearBinds);										
				addEventHandler(nextyearRangeTwo[0], 'click', rangeYearBinds);	
				break;
			case "dateRangemonthr":
				onyearRangeTwo.html(txt)
				rangedivr.append(preyearRangeTwo)			
				rangedivr.append(onyearRangeTwo)
				rangedivr.append(nextyearRangeTwo)
										
				addEventHandler(preyearRangeTwo[0], 'click', rangeYearBinds);										
				addEventHandler(nextyearRangeTwo[0], 'click', rangeYearBinds);	
				break;						
		    default:
		        console.log("种类未定义")
		}	
	}
	
	//渲染日期头
	function contontRendering(){
		var datetablecontont = $("<div></div>");
		datetablecontont.addClass("date-table-contont");	
		datebox.append(datetablecontont)
		
		var datetablecontontrangel = $("<div></div>");
		datetablecontontrangel.addClass("date-table-contont-range-l");	
		var datetablecontontranger = $("<div></div>");
		datetablecontontranger.addClass("date-table-contont-range-r");
		
		switch(obj.kind){
		    case "time":
				timeRendering("date-table-contont")
		        break;
		    case "year":
				yearTableRendering("date-table-contont")
		        break;
			case "month":
				monthTableRendering("date-table-contont")
			    break;	
			case "yearRange":
				datetablecontont.append(datetablecontontrangel)
				datetablecontont.append(datetablecontontranger)
				yearTableRendering("date-table-contont-range-l",year)
				yearTableRendering("date-table-contont-range-r",(year+1))
			    break;		
			case "monthRange":
				datetablecontont.append(datetablecontontrangel)
				datetablecontont.append(datetablecontontranger)
				monthTableRendering("date-table-contont-range-l")
				monthTableRendering("date-table-contont-range-r")
			    break;	
			case "timeRange":
				datetablecontont.append(datetablecontontrangel)
				datetablecontont.append(datetablecontontranger)
				timeRendering("date-table-contont-range-l")
				timeRendering("date-table-contont-range-r")
			    break;	
			case "dateRange":
				datetablecontont.append(datetablecontontrangel)
				datetablecontont.append(datetablecontontranger)
				tableHeadRendering("date-table-contont-range-l",year,yue,yues);
				var ryues = yues + 1;
				if(ryues>12){
					ryues = 1;
					var ryue = ryues>=10?ryues:("0" + ryues);
					tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
				}else{
					var ryue = ryues>=10?ryues:("0" + ryues);
					tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
				}				
			    break;	
			case "datetimeRange":
				datetablecontont.append(datetablecontontrangel)
				datetablecontont.append(datetablecontontranger)
				tableHeadRendering("date-table-contont-range-l",year,yue,yues);
				var ryues = yues + 1;
				if(ryues>12){
					ryues = 1;
					var ryue = ryues>=10?ryues:("0" + ryues);
					tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
				}else{
					var ryue = ryues>=10?ryues:("0" + ryues);
					tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
				}				
			    break;						
		    default:
				tableHeadRendering("date-table-contont")
		        console.log("种类未定义")
		}
	}
	
	function tableHeadRendering(pcontclass,y,m,ms){
		var datetablecontont = $("." + pcontclass)
		var datetable = $("<table></table>");
		datetable.addClass("date-table");
		var thead = document.createElement("thead");
		thead.innerHTML = "<tr>"+
						"<th>日</th>"+
						"<th>一</th>"+
						"<th>二</th>"+
						"<th>三</th>"+
						"<th>四</th>"+
						"<th>五</th>"+
						"<th>六</th>"+								
					"</tr>";
		datetable.append(thead)	
		var tbody = document.createElement("tbody");
		datetable.append(tbody)	
		datetablecontont.append(datetable)		
		tableRendering(pcontclass,y,m,ms)
	}
	
	//渲染日期表格
	// tableRendering()
	function tableRendering(pcontclass,y,m,ms){
		if(y){
			year = y		
		}
		if(m){
			yue = m;
		}
		if(ms){
			yues = ms	
		}
		tableEle(pcontclass);								
	}
	
	function rtableRendering(pcontclass){
		if(pcontclass){
			var tbody = $("." + pcontclass + " .date-table tbody");
		}else{
			var tbody = $(".date-table tbody");
		}
		tbody.html("");		
		var arr = this.dateble.tr;
		// console.log(arr)
		for(var i = 0;i<arr.length;i++){
			var tr = document.createElement("tr");
			for(var j = 0;j<arr[i].td.length;j++){
				var ites = arr[i].td[j];
				var td = document.createElement("td");
				td.innerHTML = "<div>"+ites.n+"</div>"
				tr.append(td)
				addEventHandler(td, 'click', tableBind);
			}
			tbody.append(tr)	
		}
	}
	
	//渲染尾
	function footRending(){
		var databoxfoot = $("<div></div>");	
		databoxfoot.addClass("databox-foot");
		var timesure,timeonnow,timeclear,selecttime;
		timesure = $("<div></div>");		
		timeonnow = $("<div></div>");	
		timeclear = $("<div></div>");		
		
		selecttime = $("<span></span>");
		selecttime.addClass("select-time");
		selecttime.html("选择时间");
		addEventHandler(selecttime[0], 'click', selectTimeF);
		if(obj.kind == "datetime" || obj.kind == "datetimeRange"){
			databoxfoot.append(selecttime);
		}
		
		//根据实列情况添加head元素和类名
		timesure.addClass("timesure");
		timesure.html("确定");
		databoxfoot.append(timesure);
		addEventHandler(timesure[0], 'click', suretime);
		
		timeonnow.addClass("timeonnow");
		timeonnow.html("现在");		
		addEventHandler(timeonnow[0], 'click', nowtime);
		
		if(obj.kind.indexOf("Range")==-1){
			databoxfoot.append(timeonnow);
		}
		
		timeclear.addClass("timeclear");
		timeclear.html("清除");
		databoxfoot.append(timeclear);
		addEventHandler(timeclear[0], 'click', cleartime);
		
		datebox.append(databoxfoot)
	}
	
	function rangeYearBinds(){
		if($(this).parent()[0].className.indexOf("range-div-l")!=-1){
			if(this.className.indexOf("preyear-range") != -1 && $(".date-table-contont-range-l .monthul").length>0){				
				var num = parseInt($(this).next().html()) - 1 ;
				$(this).next().html(num + "年")
				return
			}
			if(this.className.indexOf("nextyear-range") != -1 && $(".date-table-contont-range-l .monthul").length>0){
				var num = parseInt($(this).prev().html()) + 1 ;
				$(this).prev().html(num + "年")
				return
			}
			if(this.className.indexOf("preyear-range") != -1 && $(".date-table-contont-range-l .yearul").length>0){
				var nowyear = (parseInt($(this).next().html().split("-")[0]) + parseInt($(this).next().html().split("-")[1]))/2;
				nowyear = nowyear - 15;				
				$(".onyear-range").html((nowyear-7) + "年-" + (nowyear+7) + "年")
				yearTableRendering("date-table-contont-range-l",nowyear);
				return
			}			
			if(this.className.indexOf("nextyear-range") != -1 && $(".date-table-contont-range-l .yearul").length>0){
				var nowyear = (parseInt($(this).prev().html().split("-")[0]) + parseInt($(this).prev().html().split("-")[1]))/2;
				nowyear = nowyear + 15;				
				$(".onyear-range").html((nowyear-7) + "年-" + (nowyear+7) + "年")
				yearTableRendering("date-table-contont-range-l",nowyear);
				return
			}
		}
		if($(this).parent()[0].className.indexOf("range-div-r")!=-1){
			if(this.className.indexOf("preyear-range") != -1 && $(".date-table-contont-range-r .monthul").length>0){
				var num = parseInt($(this).next().html()) - 1 ;
				$(this).next().html(num + "年")
				return
			}
			if(this.className.indexOf("nextyear-range") != -1 && $(".date-table-contont-range-r .monthul").length>0){
				var num = parseInt($(this).prev().html()) + 1 ;
				$(this).prev().html(num + "年")
				return
			}
			if(this.className.indexOf("preyear-range") != -1 && $(".date-table-contont-range-r .yearul").length>0){
				var nowyear = (parseInt($(this).next().html().split("-")[0]) + parseInt($(this).next().html().split("-")[1]))/2;
				nowyear = nowyear - 15
				$(".onyear-range-two").html((nowyear-7) + "年-" + (nowyear+7) + "年")
				yearTableRendering("date-table-contont-range-r",nowyear);
				return
			}		
			if(this.className.indexOf("nextyear-range") != -1 && $(".date-table-contont-range-r .yearul").length>0){
				var nowyear = (parseInt($(this).prev().html().split("-")[0]) + parseInt($(this).prev().html().split("-")[1]))/2;
				nowyear = nowyear + 15					
				$(".onyear-range-two").html((nowyear-7) + "年-" + (nowyear+7) + "年")
				yearTableRendering("date-table-contont-range-r",nowyear);
				return
			}
		}			
	}
	
	function rangeYearBind(){
		if(this.className.indexOf("preyear-range") != -1){
			if($(".yearul").length>0 || $(".monthul").length>0){
				var ntxt = parseInt($(this).parent().find(".nowyear")[0].innerText)
				$(".range-div-l").html("");
				$(".range-div-r").html("");
				year = ntxt-1;
				if(yues==1){
					yues = 12;
					yue = 12;
				}else{
					yues = yues - 1;
					yue = yues>=10?yues:("0"+yues);
				}
				headRendingKindTwo()
				$(".date-table-contont-range-l").html("");
				$(".date-table-contont-range-r").html("");
				tableHeadRendering("date-table-contont-range-l",year,yue,yues);
				var ryues = yues + 1;
				if(ryues>12){
					ryues = 1;
					var ryue = ryues>=10?ryues:("0" + ryues);
					tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
				}else{
					var ryue = ryues>=10?ryues:("0" + ryues);
					tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
				}
			}else{
				year = year - 1;
				$(".nowyear-range").html(year + "年")
				var m = parseInt($(this).parent().parent().find(".nowmonth-range")[0].innerText);
				var n =  m>=10?m:("0"+m)
				tableRendering("date-table-contont-range-l",year,n,m);
				var s = parseInt($(this).parent().parent().find(".nowmonth-range-two")[0].innerText)
				var t = s>=10?s:("0"+s)
				$(".nowyear-range-two").html(year + "年")
				tableRendering("date-table-contont-range-r",year,t,s);
			}				
			return
		}
		if(this.className.indexOf("nextyear-range") != -1){				
			if($(".yearul").length>0 || $(".monthul").length>0){
				var ntxt = parseInt($(this).parent().find(".nowyear")[0].innerText)				
				$(".range-div-l").html("");
				$(".range-div-r").html("");
				year = ntxt;
				if(yues==1){
					yues = 12;
					yue = 12;
				}else{
					yues = yues - 1;
					yue = yues>=10?yues:("0"+yues);
				}
				headRendingKindTwo()
				$(".date-table-contont-range-l").html("");
				$(".date-table-contont-range-r").html("");
				tableHeadRendering("date-table-contont-range-l",year,yue,yues);
				var ryues = yues + 1;
				if(ryues>12){
					ryues = 1;
					var ryue = ryues>=10?ryues:("0" + ryues);
					tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
				}else{
					var ryue = ryues>=10?ryues:("0" + ryues);
					tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
				}
				return
			}else{
				year = year + 1;
				$(".nowyear-range").html(year + "年")
				var m = parseInt($(this).parent().parent().find(".nowmonth-range")[0].innerText);
				var n =  m>=10?m:("0"+m)
				tableRendering("date-table-contont-range-l",year,n,m);
				var s = parseInt($(this).parent().parent().find(".nowmonth-range-two")[0].innerText)
				var t = s>=10?s:("0"+s)
				$(".nowyear-range-two").html(year + "年")
				tableRendering("date-table-contont-range-r",year,t,s);
			}	
			return
		}
		if(this.className.indexOf("premonth-range") != -1){
			var m = parseInt($(this).parent().parent().find(".nowmonth-range")[0].innerText);
			var n =  m>=10?m:("0"+m)
			var y = parseInt($(this).parent().parent().find(".nowyear-range")[0].innerText)
			if(m-1==0){
				var s = 12;
				var t = "12";
				var ys = y-1;
				$(".nowyear-range").html(ys + "年");
				$(".nowmonth-range").html(t + "月");
				tableRendering("date-table-contont-range-l",ys,t,s);
			}else{
				var s = m-1;
				var t = s>=10?s:("0"+s)
				$(".nowyear-range").html(y + "年");
				$(".nowmonth-range").html(t + "月");
				tableRendering("date-table-contont-range-l",y,t,s);
			}
			$(".nowyear-range-two").html(y + "年");
			$(".nowmonth-range-two").html(n + "月");
			tableRendering("date-table-contont-range-r",y,n,m);			
			return
		}
		if(this.className.indexOf("nextmonth-range") != -1){
			var m = parseInt($(this).parent().parent().find(".nowmonth-range-two")[0].innerText);
			var n =  m>=10?m:("0"+m)			
			var y = parseInt($(this).parent().parent().find(".nowyear-range-two")[0].innerText);
			$(".nowyear-range").html(y + "年");
			$(".nowmonth-range").html(n + "月");
			tableRendering("date-table-contont-range-l",y,n,m);
			if(m+1>12){
				var s = 1;
				var t = "01"
				var ys = y+1
				$(".nowyear-range-two").html(ys + "年");
				$(".nowmonth-range-two").html(t + "月");
				tableRendering("date-table-contont-range-r",ys,t,s);
			}else{
				var s = m + 1;
				var t = s>=10?s:("0"+s)
				$(".nowyear-range-two").html(y + "年");
				$(".nowmonth-range-two").html(t + "月");
				tableRendering("date-table-contont-range-r",y,t,s);
			}					
			return
		}
		if(this.className.indexOf("nowyear-range-two") != -1){
			$(".range-div-r").html("")
			var num = parseInt(this.innerText)
			var txt = (num - 7) + "年-" + (num+7) + "年"
			headRendingKindTwo("dateRangeyearr",txt)
			yearTableRendering("date-table-contont-range-r");
			return
		}
		if(this.className.indexOf("nowyear-range") != -1){
			console.log(1)
			$(".range-div-l").html("")
			var num = parseInt(this.innerText)
			var txt = (num - 7) + "年-" + (num+7) + "年"
			headRendingKindTwo("dateRangeyearl",txt)
			yearTableRendering("date-table-contont-range-l");
			return
		}
		if(this.className.indexOf("nowmonth-range-two") != -1){
			var txt = $(this).prev().text()
			$(".range-div-r").html("")			
			headRendingKindTwo("dateRangeyearr",txt)
			monthTableRendering("date-table-contont-range-r");
			return
		}
		if(this.className.indexOf("nowmonth-range") != -1){
			var txt = $(this).prev().text()
			$(".range-div-l").html("")
			headRendingKindTwo("dateRangeyearl",txt)
			monthTableRendering("date-table-contont-range-l");
			return
		}
	}
	
	function yearbind(){
		if(this.className.indexOf("preyear-range-two") != -1 && $(".yearul").length>0){
			var nowyear = (parseInt($(this).next().html().split("-")[0]) + parseInt($(this).next().html().split("-")[1]))/2;			
			$(".date-table-contont-range-r .yearul").remove();
			nowyear = nowyear - 15;
			$(".onyear-range-two").html((nowyear-7) + "年-" + (nowyear+7) + "年")
			yearTableRendering("date-table-contont-range-r",nowyear)
			return
		}
		if(this.className.indexOf("preyear-range") != -1 && $(".yearul").length>0){
			var nowyear = (parseInt($(this).next().html().split("-")[0]) + parseInt($(this).next().html().split("-")[1]))/2;			
			$(".date-table-contont-range-l .yearul").remove();
			nowyear = nowyear - 15;
			$(".onyear-range").html((nowyear-7) + "年-" + (nowyear+7) + "年")
			yearTableRendering("date-table-contont-range-l",nowyear)
			return
		}
		if(this.className.indexOf("preyear") != -1 && $(".yearul").length>0){
			$(".yearul").remove();
			year = year - 15;
			headRendingKind("onyear");
			yearTableRendering("date-table-contont")
			return
		}
		
		if(this.className.indexOf("preyear") != -1){
			year = year - 1;
			$(".nowyear").html(year + "年")
			tableRendering("date-table-contont")
			return
		}
		
		if(this.className.indexOf("nextyear-range-two") != -1 && $(".yearul").length>0){
			var nowyear = (parseInt($(this).prev().html().split("-")[0]) + parseInt($(this).prev().html().split("-")[1]))/2;			
			$(".date-table-contont-range-r .yearul").remove();
			nowyear = nowyear + 15;
			$(".onyear-range-two").html((nowyear-7) + "年-" + (nowyear+7) + "年")
			yearTableRendering("date-table-contont-range-r",nowyear)
			return
		}
		if(this.className.indexOf("nextyear-range") != -1 && $(".yearul").length>0){
			console.log(1)
			var nowyear = (parseInt($(this).prev().html().split("-")[0]) + parseInt($(this).prev().html().split("-")[1]))/2;			
			$(".date-table-contont-range-l .yearul").remove();
			nowyear = nowyear + 15;
			$(".onyear-range").html((nowyear-7) + "年-" + (nowyear+7) + "年")
			yearTableRendering("date-table-contont-range-l",nowyear)
			return
		}
		
		if(this.className.indexOf("nextyear") != -1 && $(".yearul").length>0){
			$(".yearul").remove();
			year = year + 15;
			headRendingKind("onyear");
			yearTableRendering("date-table-contont")
			return
		}
		
		if(this.className.indexOf("nextyear") != -1){
			year = year + 1;
			$(".nowyear").html(year + "年")
			tableRendering("date-table-contont")
			return
		}
		
		if(this.className.indexOf("nowyear") != -1){
			headRendingKind("onyear");
			yearTableRendering("date-table-contont");
			return
		}
	}
	
	function monthbind(){
		if(this.className.indexOf("preyear-range-two") != -1 && $(".monthul").length>0){
			var nowyear = parseInt($(this).next().html())-1;
			rangsecyearr = nowyear;
			$(".onyear-range-two").html(nowyear + "年")
			return
		}
		if(this.className.indexOf("preyear-range") != -1 && $(".monthul").length>0){
			var nowyear = parseInt($(this).next().html())-1;
			rangsecyearl = nowyear;
			$(".onyear-range").html(nowyear + "年")
			return
		}
		if(this.className.indexOf("premonth") != -1 && $(".monthul").length>0){
			year = year - 1;
			$(".onyear").html(year+ "年")
			return
		}
		if(this.className.indexOf("premonth") != -1){
			yues = yues - 1;
			yue = Number(yue) - 1
			if(yue>12){
				yue = 1;
				year = year + 1;
			}
			if(yue<1){
				yue = 12
				year = year - 1;
			}
			yue = yue>=10?yue:("0" + yue);
			$(".nowyear").html(year + "年")
			$(".nowmonth").html(yue + "月")
			tableRendering()
			return
		}
		if(this.className.indexOf("nextyear-range-two") != -1 && $(".monthul").length>0){
			var nowyear = parseInt($(this).prev().html())+1;
			rangsecyearr = nowyear;
			$(".onyear-range-two").html(nowyear + "年")
			return
		}
		if(this.className.indexOf("nextyear-range") != -1 && $(".monthul").length>0){
			var nowyear = parseInt($(this).prev().html())+1;
			rangsecyearl = nowyear;
			$(".onyear-range").html(nowyear + "年")
			return
		}
		if(this.className.indexOf("nextmonth") != -1 && $(".monthul").length>0){
			year = year + 1;
			$(".onyear").html(year+ "年")
			return
		}
		if(this.className.indexOf("nextmonth") != -1){
			yues = yues + 1;
			yue = Number(yue) + 1
			if(yue>12){
				yue = 1;
				year = year + 1;
			}
			if(yue<1){
				yue = 12
				year = year - 1;
			}
			yue = yue>=10?yue:("0" + yue);
			$(".nowyear").html(year + "年")
			$(".nowmonth").html(yue + "月")
			tableRendering()
			return
		}

		if(this.className.indexOf("nowmonth") != -1){
			headRendingKind("onmonth");
			monthTableRendering("date-table-contont")
		}
	}
	
	var rangesecdayl,rangesecdayr;
	function tableBind(){
		if(this.innerText == "") return		
		if(obj.kind == "dateRange" || obj.kind == "datetimeRange"){			
			var elem = this;
			while (elem) { //循环判断至跟节点，防止点击的是div子元素
				if (elem.className && elem.className.indexOf("date-table-contont-range-l") !=-1 ) {
					var tdarr = $(".date-table-contont-range-l" + " td").removeClass("cur")
					$(this).addClass("cur")
					var y = parseInt($(this).parents(".datebox-range").find(".nowyear-range")[0].innerText);
					var m = parseInt($(this).parents(".datebox-range").find(".nowmonth-range")[0].innerText);
					m = m>=10?m:("0" + m);
					var d =  parseInt(this.innerText)>=10?parseInt(this.innerText):("0"+parseInt(this.innerText))
					rangesecdayl = y + "-" + m + "-" + d
					console.log(rangesecdayl)
					return;
				}
				if (elem.className && elem.className.indexOf("date-table-contont-range-r") !=-1 ) {
					var tdarr = $(".date-table-contont-range-r" + " td").removeClass("cur")
					$(this).addClass("cur")
					var y = parseInt($(this).parents(".datebox-range").find(".nowyear-range-two")[0].innerText);
					var m = parseInt($(this).parents(".datebox-range").find(".nowmonth-range-two")[0].innerText);
					m = m>=10?m:("0" + m);
					var d =  parseInt(this.innerText)>=10?parseInt(this.innerText):("0"+parseInt(this.innerText))
					rangesecdayr = y + "-" + m + "-" + d
					console.log(rangesecdayr)
					return;
				}
				elem = elem.parentNode;
			}	
		}else{
			var tdarr = $("#" + date.id + " td").removeClass("cur")
			$(this).addClass("cur")
			
			day = parseInt(this.innerText)
			day = day>=10?day:("0" + day);		
			var nowdate = year + "-" + yue + "-" + day
			if(obj.kind == "datetime"){
				return
			}
			$(obj.linkinput).val(nowdate);		
			$("#" + obj.id).remove();
		}		
	}	
	
	//当点击年份选择时，弹出新的渲染层
	function yearTableRendering(pcontclass,nyear){
		var yearul = $("<ul></ul>");
		yearul.addClass("yearul");
		if(!nyear){
			nyear = year
		}
		if(pcontclass=="date-table-contont-range-l"){
			rangsecyearl = nyear;
		}
		if(pcontclass=="date-table-contont-range-r"){
			rangsecyearr = nyear;
		}
		for(var i = 0;i<15;i++){
			var li = $("<li></li>")
			var y = nyear-7+i;	
			li.html(y + "年")
			if(y == nyear){
				li.addClass("cur")
			}
			yearul.append(li)
			addEventHandler(li[0], 'click', yearLiClickBind);
		}
		$("." + pcontclass).append(yearul)
	}
	
	//当点击月份选择时，弹出新的渲染层
	function monthTableRendering(pcontclass){
		var monthul = $("<ul></ul>");
		monthul.addClass("monthul");
		rangsecyearl = year;
		rangsecyearr = year;
		if(pcontclass=="date-table-contont-range-l"){
			rangesecmonthl = yue;
		}
		if(pcontclass=="date-table-contont-range-r"){
			rangesecmonthr = yue;
		}
		for(var i = 0;i<12;i++){
			var li = $("<li></li>")
			var m = i + 1;
			m = m>=10?m:("0" + m);
			li.html(m + "月")
			if(m == yue){
				li.addClass("cur")
			}
			monthul.append(li)
			addEventHandler(li[0], 'click', yueLiClickBind);
		}
		$("." + pcontclass).append(monthul)
	}
	
	//月份渲染时点击月份触发事件
	var secmonth,rangesecmonthl,rangesecmonthr;
	function yueLiClickBind(){
		switch(obj.kind){
			case "month":
				$(this).siblings().removeClass("cur");
				$(this).addClass("cur");
				secmonth = parseInt(this.innerText);
				secmonth = secmonth>=10?secmonth:("0" + secmonth);
			    break;		
			case "monthRange":
				$(this).siblings().removeClass("cur");
				$(this).addClass("cur");
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-l")!=-1){
					rangesecmonthl = parseInt(this.innerText);
					rangesecmonthl = rangesecmonthl>=10?rangesecmonthl:("0" + rangesecmonthl);
				}
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-r")!=-1){
					rangesecmonthr = parseInt(this.innerText);
					rangesecmonthr = rangesecmonthr>=10?rangesecmonthr:("0" + rangesecmonthr);
				}			
			    break;	
			case "dateRange":
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-l")!=-1){
					var ntxt = parseInt($(this).parents(".date-table-contont").prev().find(".range-div-l").eq(0).children()[1].innerText)
					$(".range-div-l").html("");
					$(".range-div-r").html("");
					year = ntxt;					
					yues = parseInt(this.innerText)
					yue = yues>=10?yues:("0"+yues);
					headRendingKindTwo()
					$(".date-table-contont-range-l").html("");
					$(".date-table-contont-range-r").html("");
					tableHeadRendering("date-table-contont-range-l",year,yue,yues);
					var ryues = yues + 1;
					if(ryues>12){
						ryues = 1;
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
					}else{
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
					}
					return
				}
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-r")!=-1){
					var ntxt = parseInt($(this).parents(".date-table-contont").prev().find(".range-div-r").eq(0).children()[1].innerText)
					$(".range-div-l").html("");
					$(".range-div-r").html("");
				
					if(parseInt(this.innerText)==1){
						year = ntxt - 1;
						yues = 12;
						yue = 12;
					}else{
						year = ntxt;
						yues = parseInt(this.innerText) - 1
						yue = yues>=10?yues:("0"+yues);
					}					
					headRendingKindTwo()
					$(".date-table-contont-range-l").html("");
					$(".date-table-contont-range-r").html("");
					tableHeadRendering("date-table-contont-range-l",year,yue,yues);
					var ryues = yues + 1;
					if(ryues>12){
						ryues = 1;
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
					}else{
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
					}
					return
				}		
			    break;	
			case "datetimeRange":
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-l")!=-1){
					var ntxt = parseInt($(this).parents(".date-table-contont").prev().find(".range-div-l").eq(0).children()[1].innerText)
					$(".range-div-l").html("");
					$(".range-div-r").html("");
					year = ntxt;					
					yues = parseInt(this.innerText)
					yue = yues>=10?yues:("0"+yues);
					headRendingKindTwo()
					$(".date-table-contont-range-l").html("");
					$(".date-table-contont-range-r").html("");
					tableHeadRendering("date-table-contont-range-l",year,yue,yues);
					var ryues = yues + 1;
					if(ryues>12){
						ryues = 1;
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
					}else{
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
					}
					return
				}
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-r")!=-1){
					var ntxt = parseInt($(this).parents(".date-table-contont").prev().find(".range-div-r").eq(0).children()[1].innerText)
					$(".range-div-l").html("");
					$(".range-div-r").html("");
				
					if(parseInt(this.innerText)==1){
						year = ntxt - 1;
						yues = 12;
						yue = 12;
					}else{
						year = ntxt;
						yues = parseInt(this.innerText) - 1
						yue = yues>=10?yues:("0"+yues);
					}					
					headRendingKindTwo()
					$(".date-table-contont-range-l").html("");
					$(".date-table-contont-range-r").html("");
					tableHeadRendering("date-table-contont-range-l",year,yue,yues);
					var ryues = yues + 1;
					if(ryues>12){
						ryues = 1;
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
					}else{
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
					}
					return
				}		
				break;
			default:
				yue = parseInt(this.innerText)
				yues = yue + 1;
				yue = yue>=10?yue:("0" + yue);
				$(".monthul").remove()
				headRendingKind()
				$(".nowmonth").html(yue + "月")
				tableRendering()
			    console.log("种类未定义")	
			
		}
	}	
	
	//年份渲染时点击年份触发事件
	var secyear,rangsecyearl,rangsecyearr;
	function yearLiClickBind(){
		switch(obj.kind){
			case "year":
				$(this).siblings().removeClass("cur");
				$(this).addClass("cur");
				secyear = parseInt(this.innerText);
			    break;
			case "yearRange":
				$(this).siblings().removeClass("cur");
				$(this).addClass("cur");
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-l")!=-1){
					rangsecyearl = parseInt(this.innerText);
				}
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-r")!=-1){
					rangsecyearr = parseInt(this.innerText);
				}
			    break;	
			case "dateRange":
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-l")!=-1){
					year = parseInt(this.innerText);					
					$(".range-div-l").html("");
					$(".range-div-r").html("");
					year = parseInt(this.innerText);
					if(yues==1){
						yues = 12;
						yue = 12;
					}else{
						yues = yues - 1;
						yue = yues>=10?yues:("0"+yues);
					}					
					headRendingKindTwo()
					$(".date-table-contont-range-l").html("");
					$(".date-table-contont-range-r").html("");
					console.log(1)
					tableHeadRendering("date-table-contont-range-l",year,yue,yues);					
					var ryues = yues + 1;
					if(ryues>12){
						ryues = 1;
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
					}else{
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
					}
					return
				}
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-r")!=-1){
					year = parseInt(this.innerText);
					$(".range-div-l").html("");
					$(".range-div-r").html("");
					year = parseInt(this.innerText)-1;
					if(yues==1){
						yues = 12;
						yue = 12;
					}else{
						yues = yues - 1;
						yue = yues>=10?yues:("0"+yues);
					}					
					headRendingKindTwo()
					$(".date-table-contont-range-l").html("");
					$(".date-table-contont-range-r").html("");
					tableHeadRendering("date-table-contont-range-l",year,yue,yues);					
					var ryues = yues + 1;
					if(ryues>12){
						ryues = 1;
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
					}else{
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
					}
					return
				}
			    break;	
			case "datetimeRange":
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-l")!=-1){
					year = parseInt(this.innerText);					
					$(".range-div-l").html("");
					$(".range-div-r").html("");
					year = parseInt(this.innerText);
					if(yues==1){
						yues = 12;
						yue = 12;
					}else{
						yues = yues - 1;
						yue = yues>=10?yues:("0"+yues);
					}					
					headRendingKindTwo()
					$(".date-table-contont-range-l").html("");
					$(".date-table-contont-range-r").html("");
					tableHeadRendering("date-table-contont-range-l",year,yue,yues);					
					var ryues = yues + 1;
					if(ryues>12){
						ryues = 1;
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
					}else{
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
					}
					return
				}
				if($(this).parent().parent()[0].className.indexOf("date-table-contont-range-r")!=-1){
					year = parseInt(this.innerText);
					$(".range-div-l").html("");
					$(".range-div-r").html("");
					year = parseInt(this.innerText)-1;
					if(yues==1){
						yues = 12;
						yue = 12;
					}else{
						yues = yues - 1;
						yue = yues>=10?yues:("0"+yues);
					}					
					headRendingKindTwo()
					$(".date-table-contont-range-l").html("");
					$(".date-table-contont-range-r").html("");
					tableHeadRendering("date-table-contont-range-l",year,yue,yues);					
					var ryues = yues + 1;
					if(ryues>12){
						ryues = 1;
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year+1,ryue,ryues);
					}else{
						var ryue = ryues>=10?ryues:("0" + ryues);
						tableHeadRendering("date-table-contont-range-r",year,ryue,ryues);
					}
					return
				}
			    break;	
			default:
				year = parseInt(this.innerText)
				$(".yearul").remove()
				headRendingKind()
				$(".nowyear").html(year + "年")
				tableRendering()
			    console.log("种类未定义")
				
		}	
	}	
	
	//选择时间
	function selectTimeF(){
		console.log($(".selet-time-div"))
		if(obj.kind == "datetimeRange"){
			$(".range-div-l").html("")
			$(".range-div-r").html("")
			if($(".selet-time-div").length==0){
				this.innerText = "返回日期"
				headRendingKindTwo("timeRange")
				timeRendering("date-table-contont-range-l")
				timeRendering("date-table-contont-range-r")
			}else{
				this.innerText = "选择时间";
				headRendingKindTwo("datetimeRange")
				$(".selet-time-div").remove()
			}
		}else{
			if($(".selet-time-div").length==0){
				this.innerText = "返回日期"
				headRendingKind("select-time");
				timeRendering("date-table-contont");
			}else{
				if(sech!=0&&secm!=0&&secs!=0){
					this.innerText = sech + ":" + secm + ":" + secs
				}else{
					this.innerText = "选择时间"
				}
				headRendingKind();
				$(".selet-time-div").remove()
			}
		}					
	}
	
	//time select渲染
	function timeRendering(pcontclass){
		sech=0,secm=0,secs=0;
		var selettimediv = $("<div></div>")
		selettimediv.addClass("selet-time-div");
		
		var hdiv,mdiv,sdiv;
		hdiv = $("<div></div>");
		mdiv = $("<div></div>")
		sdiv = $("<div></div>")
		
		hdiv.append("<p>时</p>")
		mdiv.append("<p>分</p>")
		sdiv.append("<p>秒</p>")
		
		var hul,mul,sul;
		hul = document.createElement("ul");
		mul = document.createElement("ul");
		sul = document.createElement("ul");
		for(var i = 0;i<24;i++){
			var h = i
			h = h>=10?h:("0" + h);
			var li = document.createElement("li");
			li.innerText = h;
			hul.appendChild(li)
			addEventHandler(li, 'click', seletTimeNum);
		}
		hdiv.append(hul)
		
		for(var j = 0;j<60;j++){
			var m = j;
			m = m>=10?m:("0" + m);
			var li = document.createElement("li");
			li.innerText = m;
			mul.appendChild(li)
			addEventHandler(li, 'click', seletTimeNum);
		}
		mdiv.append(mul)
		
		for(var n = 0;n<60;n++){
			var s = n;
			s = s>=10?s:("0" + s);
			var li = document.createElement("li");
			li.innerText = s;
			sul.appendChild(li)
			addEventHandler(li, 'click', seletTimeNum);
		}
		sdiv.append(sul)
		
		selettimediv.append(hdiv)
		selettimediv.append(mdiv)
		selettimediv.append(sdiv)
		
		$("." + pcontclass).append(selettimediv)
	}
	var sech=0,secm=0,secs=0;rsechl="00",rsecml="00",rsecsl="00",rsechr="00",rsecmr="00",rsecsr="00";
	function seletTimeNum(){
		$(this).siblings().removeClass("cur");
		$(this).addClass("cur");
		if(obj.kind == "timeRange" || obj.kind == "datetimeRange"){
			var elem = this;
			while (elem) { //循环判断至跟节点，防止点击的是div子元素
				if (elem.className && elem.className.indexOf("date-table-contont-range-l") !=-1 ) {
					if($(this).parent().prev().text() == "时"){
						rsechl = this.innerText;
					}
					if($(this).parent().prev().text() == "分"){
						rsecml = this.innerText;
					}
					if($(this).parent().prev().text() == "秒"){
						rsecsl = this.innerText;
					}
					return;
				}
				if (elem.className && elem.className.indexOf("date-table-contont-range-r") !=-1 ) {
					if($(this).parent().prev().text() == "时"){
						rsechr = this.innerText;
					}
					if($(this).parent().prev().text() == "分"){
						rsecmr = this.innerText;
					}
					if($(this).parent().prev().text() == "秒"){
						rsecsr = this.innerText;
					}
					return;
				}
				elem = elem.parentNode;
			}
		}else{
			if($(this).parent().prev().text() == "时"){
				sech = this.innerText;
			}
			if($(this).parent().prev().text() == "分"){
				secm = this.innerText;
			}
			if($(this).parent().prev().text() == "秒"){
				secs = this.innerText;
			}
		}	
	}	
		
	//foot清除时间按钮
	function cleartime(){
		$(obj.linkinput).val("");
		$("#" + obj.id).remove();
	}
	
	//foot现在时间按钮
	function nowtime(){
		var dates = new Date();
		year = dates.getFullYear()
		yue = (dates.getMonth() + 1)>=10?(dates.getMonth() + 1):("0" + (dates.getMonth() + 1));
		day = dates.getDate()>=10?dates.getDate():("0" + dates.getDate());
		h = dates.getHours()
		m = dates.getMinutes()
		s = dates.getSeconds()
		var nowdate;
		switch(obj.kind){
		    case "date":
				nowdate = year + "-" + yue + "-" + day;
		        break;
		    case "time":
				nowdate = h + ":" + m + ":" + s;
		        break;
			case "datetime":
				nowdate = year + "-" + yue + "-" + day + " " + h + ":" + m + ":" + s;
			    break;	
			case "year":
				nowdate = year;
			    break;
			case "month":
				nowdate = year + "-" + yue;
			    break;				
		    default:
		        console.log("种类未定义")
		}
		$(obj.linkinput).val(nowdate);
		$("#" + obj.id).remove();
	}
		
	//foot确定时间按钮
	function suretime(){
		var datesure = new Date();
		
		h = sech?sech:"00";
		m = secm?secm:"00";
		s = secs?secs:"00";
		year = secyear?secyear:year;
		yue = secmonth?secmonth:yue; 
			
		var nowdate;
		switch(obj.kind){
		    case "date":
				nowdate = year + "-" + yue + "-" + day;
		        break;
		    case "time":
				nowdate = h + ":" + m + ":" + s;
		        break;
			case "datetime":
				nowdate = year + "-" + yue + "-" + day + " " + h + ":" + m + ":" + s;
			    break;	
			case "year":
				nowdate = year;	
				break;
			case "month":
				nowdate = year + "-" + yue;	
				break;
			case "yearRange":
				nowdate = timeNumVS({y:rangsecyearl},{y:rangsecyearr});	
				break;
			case "monthRange":		
				nowdate = timeNumVS({y:rangsecyearl,m:rangesecmonthl},{y:rangsecyearr,m:rangesecmonthr});	
				break;	
			case "timeRange":
				nowdate = timeNumVS({h:rsechl,min:rsecml,s:rsecsl},
				{h:rsechr,min:rsecmr,s:rsecsr});	
				break;	
			case "dateRange":
				if(!rangesecdayl){
					rangesecdayl = datesure.getFullYear() + "-" + (datesure.getMonth() + 1) + "-" + datesure.getDate()
				}
				if(!rangesecdayr){
					rangesecdayr = datesure.getFullYear() + "-" + (datesure.getMonth() + 1) + "-" + datesure.getDate()
				}
				nowdate = timeNumVS(rangesecdayl,rangesecdayr)
				break;	
			case "datetimeRange":
				if(!rangesecdayl){
					rangesecdayl = datesure.getFullYear() + "-" + (datesure.getMonth() + 1) + "-" + datesure.getDate() + " "
					+ rsechl + ":" + rsecml + ":" + rsecsl;
				}else{
					rangesecdayl = rangesecdayl + " " + rsechl + ":" + rsecml + ":" + rsecsl;
				}
				if(!rangesecdayr){
					rangesecdayr = datesure.getFullYear() + "-" + (datesure.getMonth() + 1) + "-" + datesure.getDate() + " "
					+ rsechr + ":" + rsecmr + ":" + rsecsr;
				}else{
					rangesecdayr = rangesecdayr + " " + rsechr + ":" + rsecmr + ":" + rsecsr;
				}	
				console.log(rangesecdayl,rangesecdayr)
				nowdate = timeNumVS(rangesecdayl,rangesecdayr)
				break;	
		    default:
		        console.log("种类未定义")
		}
		$(obj.linkinput).val(nowdate);
		$("#" + obj.id).remove();
	}	
		
	function timeNumVS(t1,t2){
		switch(obj.kind){
			case "yearRange":
				var max,min;
				max = t1.y>t2.y?t1.y:t2.y
				min = t1.y<t2.y?t1.y:t2.y
				return min + " ~ " + max
				break;
			case "monthRange":
				var max,min;
				max = (t1.y*12+parseInt(t1.m))>(t2.y*12+parseInt(t2.m))?(t1.y + "-" + t1.m):(t2.y + "-" + t2.m)
				min = (t1.y*12+parseInt(t1.m))<(t2.y*12+parseInt(t2.m))?(t1.y + "-" + t1.m):(t2.y + "-" + t2.m)
				return min + " ~ " + max
				break;	
			case "timeRange":
				var max,min;
				max = (parseInt(t1.h)*3600+parseInt(t1.min)*60+parseInt(t1.s))>
					(parseInt(t2.h)*3600+parseInt(t2.min)*60+parseInt(t2.s))?
					(t1.h + ":" + t1.min + ":" + t1.s):(t2.h + ":" + t2.min + ":" + t2.s)
				min = (parseInt(t1.h)*3600+parseInt(t1.min)*60+parseInt(t1.s))<
					(parseInt(t2.h)*3600+parseInt(t2.min)*60+parseInt(t2.s))?
					(t1.h + ":" + t1.min + ":" + t1.s):(t2.h + ":" + t2.min + ":" + t2.s)
				return min + " ~ " + max
				break;	
			case "dateRange":
				var max,min;
				max = parseInt(t1.split("-")[0])*366 + parseInt(t1.split("-")[1])*30 + parseInt(t1.split("-")[2])>
					parseInt(t2.split("-")[0])*366 + parseInt(t2.split("-")[1])*30 + parseInt(t2.split("-")[2])?
					t1:t2;
				min = parseInt(t1.split("-")[0])*366 + parseInt(t1.split("-")[1])*30 + parseInt(t1.split("-")[2])<
					parseInt(t2.split("-")[0])*366 + parseInt(t2.split("-")[1])*30 + parseInt(t2.split("-")[2])?
					t1:t2;
				return 	min + " ~ " + max
				break;	
			case "datetimeRange":
				var max,min;
				if(t1.split(" ")[0] == t2.split(" ")[0]){
					var tb1 = t1.split(" ")[1].split(":");
					var tb2 = t2.split(" ")[1].split(":");
					max = (parseInt(tb1[0])*3600+parseInt(tb1[1])*60+parseInt(tb1[2]))>
						(parseInt(tb2[0])*3600+parseInt(tb2[1])*60+parseInt(tb2[2]))?t1:t2						
					min = (parseInt(tb1[0])*3600+parseInt(tb1[1])*60+parseInt(tb1[2]))<
						(parseInt(tb2[0])*3600+parseInt(tb2[1])*60+parseInt(tb2[2]))?t1:t2
				}else{
					var tb1 = t1.split(" ")[0].split("-");
					var tb2 = t2.split(" ")[0].split("-");
					max = parseInt(tb1[0])*366 + parseInt(tb1[1])*30 + parseInt(tb1[2])>
						parseInt(tb2[0])*366 + parseInt(tb2[1])*30 + parseInt(tb2[2])?
						t1:t2;
					min = parseInt(tb1[0])*366 + parseInt(tb1[1])*30 + parseInt(tb1[2])<
						parseInt(tb2[0])*366 + parseInt(tb2[1])*30 + parseInt(tb2[2])?
						t1:t2;
				}
				return 	min + " ~ " + max
				break;			
		}
		
	}	
		
	//初始化
	this.init = function(){
		headRending();
		contontRendering()
		footRending();
	}		
}

/**
 * 时间选择框
 * @param obj	
 * 参数为对象，属性有：
 * id
 * 键值
 * 类型（时间'time'，日期'date'，时间和日期'datetime',年'year',月'month'）
 * 点击触发事件
 * 日期选择
 * 时间选择
	var datetime = new Datetimes({
 	id:"datetime",
 	label:"时间选择",//to do
 	kind:"date",
 	nowtime:true,//to do
 })
 * ---------------------------- usage:----------------------------
 */

function Datetimes(dates){
	var obj = dates;	
	// console.log(obj)
	this.id = dates.id;
		
	function rendering(){
		var div = $("#" + dates.id);
		// div.append("")
		var divinput = $("<div></div>");
		divinput.addClass("datetime-input")
		var input = document.createElement("input");
		switch(obj.kind){
			case "date":
				input.placeholder = "yyyy-MM-dd";
			    break;
			case "time":
				input.placeholder = "h:m:s";
			    break;
			case "datetime":
				input.placeholder = "yyyy-MM-dd h:m:s";
			    break;
			case "year":
				input.placeholder = "yyyy";
			    break;	
			case "month":
				input.placeholder = "yyyy-MM";
			    break;	
			case "dateRange":
				input.placeholder = "yyyy-MM-dd"+ " ~ " + "yyyy-MM-dd";
				break;
			case "yearRange":
				input.placeholder = "yyyy"+ " ~ " + "yyyy";
				break;	
			case "monthRange":
				input.placeholder = "yyyy-MM"+ " ~ " + "yyyy-MM";
				break;	
			case "timeRange":
				input.placeholder = "h:m:s"+ " ~ " + "h:m:s";
				break;	
			case "datetimeRange":
				input.placeholder = "yyyy-MM-dd h:m:s"+ " ~ " + "yyyy-MM-dd h:m:s";
				break;	
			default:
			    console.log("种类未定义")
		}
				
		divinput.append(input)
		div.append(divinput)
		addEventHandler(input, "focus", datetimeshow)
	}
	
	function datetimeshow(){
		if($("#jbdate").length>0){
			$("#jbdate").remove();
		}
		var div = $("<div></div>")
		div[0].id = "jbdate";
		div.css({
			left:0 + "px",
			top:this.clientHeight + "px",
			position:"absolute",
			zIndex:"999999999",
			background:"#fff"
		})
		//添加类名确定时间框浮现位置
		$(this).parent().append(div)
		var newDate = new Jbdate({
			id:"jbdate",
			linkinput:this,
			kind:obj.kind,
			date:"2018-12-12",
		});
		newDate.init()
	}
	
	//点击页面其他层级，选择弹框隐藏
	document.addEventListener('click', function(){
		var e = e || window.event; //浏览器兼容性
		var elem = e.target || e.srcElement;
		
		//isConnected的意思是判断检查是否与节点连接上因为在页面上会做到一些页面的删除导致父节点为null；所以通过该属性做中转
		if(elem.isConnected == false){
			return
		}
		while (elem) { //循环判断至跟节点，防止点击的是div子元素
			if (elem.id && elem.id== dates.id) {
				return;
			}
			elem = elem.parentNode;
		}
		$("#" + dates.id + " #jbdate").remove();	
	})
	
	this.init = function(){
		rendering()
	}
}

// var datetime = new Datetimes({	
// 	id:"datetime",
// 	kind:"date",
// 	nowtime:true,
// })

// datetime.init()

// var datetime2 = new Datetimes({	
// 	id:"datetime2",
// 	kind:"time",
// 	nowtime:true,
// })
// datetime2.init()

// var datetime3 = new Datetimes({	
// 	id:"datetime3",
// 	kind:"year",
// 	nowtime:true,
// })
// datetime3.init()

// var datetime4 = new Datetimes({	
// 	id:"datetime4",
// 	kind:"month",
// 	nowtime:true,
// })
// datetime4.init()

// var datetime5 = new Datetimes({	
// 	id:"datetime5",
// 	kind:"datetime",
// 	nowtime:true,
// })
// datetime5.init()

// var datetime6 = new Datetimes({	
// 	id:"datetime6",
// 	kind:"dateRange",
// 	nowtime:true,
// })
// datetime6.init()

// var datetime7 = new Datetimes({	
// 	id:"datetime7",
// 	kind:"timeRange",
// 	nowtime:true,
// })
// datetime7.init()

// var datetime8 = new Datetimes({	
// 	id:"datetime8",
// 	kind:"yearRange",
// 	nowtime:true,
// })
// datetime8.init()

// var datetime9 = new Datetimes({	
// 	id:"datetime9",
// 	kind:"monthRange",
// 	nowtime:true,
// })
// datetime9.init()

// var datetime10 = new Datetimes({	
// 	id:"datetime10",
// 	kind:"datetimeRange",
// 	nowtime:true,
// })
// datetime10.init()

/**
 * 三级联动
 * @param obj
 * 参数为对象，属性有：
 * id (必填)
 * keys  (必填)  objectarr  
 * 			key   一级关键键值 (必填)
 * 			name  一级名字 (必填)
 * 			key   二级关键键值 (必填)
 *			name  二级名字 (必填)
 * 			key   三级关键键值 (必填)
 * 			name  三级名字 (必填)
 * class
 * 方法有：

 * ---------------------------- usage:----------------------------
 * var newThrlinkage = new Morelinkage({
	id:"jbdate",
	keys:[{
		key:"shi",
		name:"市"
	},{
		key:"xian",
		name:"县"
	},{
		key:"qu",
		name:"区"
	}],
	data:areadata,
	codekey:"code"	
});
 * 
 * 
 * 
 */
function Morelinkage(item){
	var obj = item;
	this.id = item.id;
	this.keys = item.keys,
	this.data = item.data;
	this.codekey = item.codekey
	var arrscenter = [];
	
	//将分层对象数组集合分离成一个新的包含所有层级元素的数组集合
	function dataArr(){	
		// console.log(item.data)
		var data = item.data
		for(var i = 0;i<data.length;i++){
			arrscenter.push({
				data:data[i],	
				parent:"all"
			})
			if(data[i].child && data[i].child.length>0){
				forEachs(data[i])
			}
		}
	}
	function forEachs(fordata){
		if(fordata.child){
			$(fordata.child).each(function(idx,its){
				if(its){
					arrscenter.push({
						data:its,	
						parent:fordata[item.codekey]
					})
					if(its.child&&its.child.length>0){
						forEachs(its)
					}
				}
			})
		}	
	}
	
	//第一级selet元素渲染
	function oneRendering(){
		// console.log(item.data)
		var datebox = document.getElementById(item.id);
		for(var i=0;i<item.keys.length;i++){
			var div = document.createElement("div");
			div.className = "thr-linkage-div-d";
			var divs = document.createElement("div");			
			divs.className = "thr-linkage-div-d-label";
			divs.innerHTML = "<label for='"+item.keys[i].key+"' data-"+item.codekey+"='' data-key='"+item.keys[i].key+"'>请选择"+item.keys[i].name+"级</label>";
			div.appendChild(divs)
			var ul = document.createElement("ul");
			ul.className = "thr-linkage-div-d-ul"
			var datas = item.data
			if(i==0){
				$(datas).each(function(idx,ites){
					// console.log(ites)
					var li = document.createElement("li");
					li.setAttribute("data-key",item.keys[i].key);
					li.setAttribute("data-" + item.codekey,ites[item.codekey]);
					// console.log(item.keys[i])
					li.innerText = ites[item.keys[i].key];
					ul.appendChild(li)
				})
			}			
			div.appendChild(ul)
			datebox.appendChild(div)
		}
	}
	
	//label的点击事件
	function labelBind(){
		var selectdiv = $(".thr-linkage-div-d-label")
		selectdiv.each(function(idx,ites){
			ites.addEventListener('click', function(){
				console.log(this.firstChild.getAttribute("data-key"))
				if(idx!=0 && selectdiv[idx-1].firstChild.getAttribute("data-" + item.codekey)==""){
					console.log("上级没选,请选择上级") 
					return
				}				
				this.nextSibling.style.display = "block"
				// if(this.getFirstChild.getAttribute("key"))
			})
		})		
	}
	
	//点击对应触发的层级连锁	
	function liClick(){
		var that = this;
		$(item.keys).each(function(idy,ite){
			if(that.getAttribute("data-key") == ite.key){
				$(".thr-linkage-div-d-label").each(function(idz,its){												
					if(its.firstChild.getAttribute("data-key") == ite.key){
						its.firstChild.innerText = that.innerText;
						its.firstChild.setAttribute("data-" + item.codekey,that.getAttribute("data-" + item.codekey))
						that.parentNode.style.display = "none";						
					}	
					if(idz>idy){
						its.innerHTML = "<label for='"+item.keys[idz].key+"' data-"+item.codekey+"='' data-key='"+item.keys[idz].key+"'>请选择"+item.keys[idz].name+"级</label>";
						if(its.nextSibling){
							its.parentNode.removeChild(its.nextSibling);
						}								
					} 								
					if(idz-idy == 1){
						var datas = arrscenter;
						// console.log(datas)	
						var ul = document.createElement("ul");
						ul.className = "thr-linkage-div-d-ul"
						$(datas).each(function(idx,ites){
							if(ites.parent == that.getAttribute("data-" + item.codekey)){
								var li = document.createElement("li");
								li.setAttribute("data-key",item.keys[idz].key);
								li.setAttribute("data-" + item.codekey,ites.data[item.codekey]);
								li.innerText = ites.data[item.keys[idz].key];
								addEventHandler(li, 'click', liClick);
								ul.appendChild(li)								
							}									
						})
						its.parentNode.appendChild(ul)
					}
				})
			}
		})	
	}
	
	//元素节点点击选择事件
	function liBind(){
		var selectdiv = document.querySelectorAll(".thr-linkage-div-d-ul li");
		$(selectdiv).each(function(idx,ites){
			ites.addEventListener('click', liClick)
		})
	}
	
	//点击页面其他层级，选择弹框隐藏
	document.addEventListener('click', function(){
		var e = e || window.event; //浏览器兼容性
		var elem = e.target || e.srcElement;
		while (elem) { //循环判断至跟节点，防止点击的是div子元素
			if (elem.id && elem.id== item.id) {
				return;
			}
			elem = elem.parentNode;
		}
		$(".thr-linkage-div-d-ul").each(function(idx,ites){
			ites.style.display = "none"
		})	
	})
	
	function init(){
		dataArr()
		oneRendering()
		labelBind()
		liBind()	
	}
	
	init()
}

// var newThrlinkage = new Morelinkage({
// 	id:"thrlinkage",
// 	keys:[{
// 		key:"shi",
// 		name:"市"
// 	},{
// 		key:"xian",
// 		name:"县"
// 	},{
// 		key:"qu",
// 		name:"区"
// 	}],
// 	data:areadata,
// 	codekey:"code"	
// 	});

var newForlinkage = new Morelinkage({
	id:"forlinkage",
	keys:[{
		key:"yj",
		name:"类"
	},{
		key:"ej",
		name:"属性"
	},{
		key:"sj",
		name:"用途"
	},{
		key:"fj",
		name:"品牌"
	}],
	data:shopdata,
	codekey:"zhi"	
});

//为新添加的元素节点添加点击事件
function addEventHandler(oTarget, sEventType, fnHandler) {
   if (oTarget.addEventListener) {   //监听IE9，谷歌和火狐  
		oTarget.addEventListener(sEventType, fnHandler, false);    
   } else if (oTarget.attachEvent) {  //IE  
		oTarget.attachEvent("on" + sEventType, fnHandler);    
	} else {    
		oTarget["on" + sEventType] = fnHandler;    
	}    
}