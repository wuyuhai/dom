/**
 * 页码组件
 * @param obj	
 * 参数为对象，属性有：
 * id ----- string
 * 方法有：
 * comeback
var normtable = new Morenormtable({
 	
 })
 * ---------------------------- usage:----------------------------
 */
function Morenormtable(obj){
	var obj = obj;
	var tablediv = $("#" + obj.id);
	var normtablecontont = $("<div></div>");
	normtablecontont.addClass("normtablecontont")
	tablediv.append(normtablecontont)
	var table = $("<table></table>");
	table.prop("cellspacing",0)
	table.prop("cellpadding",0)
	table.prop("border",0)
	normtablecontont.append(table)
	
	var gz = {
		txm:{
			lev:-2,
			name:"条形码"
		},
		goodm:{
			lev:-1,
			name:"商家编码"
		},
		color:{
			lev:1,
			name:"颜色"
		},
	}
	
	this.comeback = function(){
		
	}
	
	function itemsfun(item,arr){
		var item = item;
		var arr = arr;
			
		var narrs = [];
		if(item.length == 0){
			for(var i = 0;i<arr.length;i++){
				narrs.push([arr[i].name])
			}
		}else{
			item.forEach(function(items,idx){				
				for(var j = 0;j<arr.length;j++){
					var newarr = [arr[j].name].concat(items)								
					narrs.push(newarr)
				}
			})
		}
		return narrs
	}
	
	function theadrendering(tableitem){
		var thead = $("<thead></thead>");
		$("#" + obj.id + " .normtablecontont table").append(thead);
		var tr = $("<tr></tr>");
		thead.append(tr);
		tr.append("<th>商家编码</th>");
		tr.append("<th>条形码</th>");
		
		var items = []
		if(tableitem.styles.sec.length>0){
			tr.prepend("<th>款式</th>");
		}
		if(tableitem.img.sec.length>0){
			tr.prepend("<th>图片</th>");
		}
		if(tableitem.heigt.sec.length>0){
			tr.prepend("<th>质量</th>");
		}
		if(tableitem.cicun.sec.length>0){
			tr.prepend("<th>尺寸</th>");
		}
		if(tableitem.colors.sec.length>0){
			tr.prepend("<th>颜色</th>");	
		}
		if(tableitem.colors.sec.length>0){
			items = itemsfun(items,tableitem.colors.sec)
		}
		if(tableitem.cicun.sec.length>0){
			items = itemsfun(items,tableitem.cicun.sec)
		}
		if(tableitem.heigt.sec.length>0){
			items = itemsfun(items,tableitem.heigt.sec)
		}
		if(tableitem.img.sec.length>0){
			items = itemsfun(items,tableitem.img.sec)
		}
		if(tableitem.styles.sec.length>0){
			items = itemsfun(items,tableitem.styles.sec)
		}
		// console.log(items)
		tbodyrendering(items)
	}
	
	function tbodyrendering(items){
		var tbody = $("<tbody></tbody>");
		$("#" + obj.id + " .normtablecontont table").append(tbody);
		for(var i = 0;i<items.length;i++){
			var tr = $("<tr></tr>");
			// console.log(items[i])
			for(var j = 0;j<items[i].length;j++){		
				var td = $("<td></td>")
				td.html(items[i][items[i].length-1-j]);
				tr.append(td)
			}
			var sjtd = $("<td></td>");
			var tmtd = $("<td></td>");
			sjtd.html("<input />")
			tmtd.html("<input />")
			
			tr.append(sjtd)
			tr.append(tmtd)			
			tbody.append(tr);
		}
	}
	
	this.tablerendering = function(tableitem){
		$("#" + obj.id + " .normtablecontont table").html("")		
		theadrendering(tableitem)					
	}
}

function Htmlrendering(obj){
	var obj = obj;
	var objthis = this
	this.normtable = "";
	var htmls = $("#" + obj.id);
	var htmlscont = $("<div></div>");
	htmlscont.addClass("htmlscont");
	
	htmls.append(htmlscont)
	
	function rendering(){
		var div = $("<div></div>")
		div.html('<p>颜色选择</p>'+
					'<div>'+
						'<p>色系</p>'+
						'<div class="colorkind">'+
							
						'</div>'+
					'</div>	'+
					'<div>'+
						'<p>色类</p>'+
						'<div class="colors">'+
			
						'</div>'+
					'</div>')
		
		htmlscont.append(div)
		for(var i = 0;i<obj.mors.color.length;i++){
			var input = $("<input />")
			input.attr("type","checkbox")
			input.attr("name","colorkinds")
			input.css({
				marginLeft:17.5 + "px",
			})
			var label = $("<label></label>")
			label.html(obj.mors.color[i].name);
			input.val(obj.mors.color[i].num)
			addEventHandler(input[0], 'click', seleccolorkind);	
			$(".colorkind").append(input)
			$(".colorkind").append(label)
		}
	}
	
	function renderingcolor(num){
		$(".colors").html("");
		for(var i = 0;i<obj.mors.color.length;i++){
			if(obj.mors.color[i].num == num){
				for(var j = 0;j<obj.mors.color[i].child.length;j++){
					var input = $("<input />")
					input.attr("type","checkbox")
					input.attr("name","colors")
					input.css({
						marginLeft:17.5 + "px",
					})
					hadselect.colors.sec.forEach(function(item,idx){
						if(item.num == obj.mors.color[i].child[j].num){
							input.prop("checked",true)
						}
					})
					var label = $("<label></label>")
					label.html(obj.mors.color[i].child[j].name);
					input.val(obj.mors.color[i].child[j].num)
					addEventHandler(input[0], 'click', seleccolors);			
					$(".colors").append(input)
					$(".colors").append(label)
				}
				return
			}
		}				
	}
	
	function renderingtwo(){
		var div = $("<div></div>")	
		div.html('<p>尺码规格</p>'+
					'<div class="gg">'+
					'</div>');
		htmlscont.append(div)
		for(var i = 0;i<obj.mors.cicun.length;i++){
			var input = $("<input />")
			input.attr("type","checkbox")
			input.attr("name","cicun")
			input.css({
				marginLeft:17.5 + "px",
			})
			var label = $("<label></label>")
			label.html(obj.mors.cicun[i].name);
			input.val(obj.mors.cicun[i].cc)	
			addEventHandler(input[0], 'click', seleccolors);
			$(".gg").append(input)
			$(".gg").append(label)
		}			
	}
	
	function renderingthr(){
		var div = $("<div></div>")
		div.html('<p>生成表单</p>')
		var normtable = $("<div></div>");
		normtable.attr("id","normtable");
		normtable.addClass("normtable")
		div.append(normtable);
		htmlscont.append(div)	
		objthis.normtable = new Morenormtable({
			id:"normtable"
		})
	}
	
	var hadselect = {
		colors:{
			name:"颜色",
			sec:[]
		},
		cicun:{
			name:"尺寸",
			sec:[],
		},
		heigt:{
			name:"重量",
			sec:[
			// 	{
			// 	name:"58kg",
			// 	num:58
			// },
			],
		},
		img:{
			name:"图片",
			sec:[
			// 	{
			// 	name:"人物",
			// 	num:1
			// },{
			// 	name:"天使",
			// 	num:2
			// },{
			// 	name:"动物",
			// 	num:3
			// },
			],
		},
		styles:{
			name:"款式",
			sec:[
				{
				name:"花款",
				num:1
			},{
				name:"天空款",
				num:2
			},{
				name:"海洋款",
				num:3
			},
			],
		}
	};
	function seleccolors(){
		var t = this;
		if($(this)[0].checked==true){
			if($(this).parent()[0].className.indexOf("gg")!=-1){
				hadselect.cicun.sec.push({name:$(this).next().html(),num:$(this).val()})
			}
			if($(this).parent()[0].className.indexOf("colors")!=-1){
				hadselect.colors.sec.push({name:$(this).next().html(),num:$(this).val()})
			}		
		}else{
			var arrs = [];		
			if($(this).parent()[0].className.indexOf("colors")!=-1){
				arrs = hadselect.colors.sec
			}
			if($(this).parent()[0].className.indexOf("gg")!=-1){
				arrs = hadselect.cicun.sec
			}
			arrs.forEach(function(item,idx){
				if(item.num == $(t).val()){
					arrs.splice(idx, 1)
					if($(t).parent()[0].className.indexOf("colors")!=-1){
						hadselect.colors.sec = arrs
					}
					if($(t).parent()[0].className.indexOf("gg")!=-1){
						hadselect.cicun.sec = arrs
					}
				}
			})			
		}
		objthis.normtable.tablerendering(hadselect)
	}
	
	function seleccolorkind(){	
		$(this).parent().children("input").prop("checked",false)
		$(this).prop("checked",true)
		if($(this)[0].checked==true){
			renderingcolor($(this).val())
		}
	}
		
	this.init = function(){
		rendering();
		renderingtwo();
		renderingthr()
	}
	this.comeback = function(){
		
	}
}


var mors = {
	color:[{
		name:"白色系",
		num:"001",
		child:[{
			name:"白色",
			num:"001001"
		},{
			name:"乳白",
			num:"001002"
		},{
			name:"米白",
			num:"001003"
		}]
	},{
		name:"黑色系",
		num:"002",
		child:[{
			name:"黑色",
			num:"002001"
		}]
	},{
		name:"灰色系",
		num:"003",
		child:[{
			name:"灰色",
			num:"003001"
		},{
			name:"浅灰",
			num:"003002"
		},{
			name:"中灰",
			num:"003003"
		},{
			name:"深灰",
			num:"003004"
		},{
			name:"银灰",
			num:"003005"
		}]
	},{
		name:"红色系",
		num:"004",
		child:[{
			name:"红色",
			num:"004001"
		},{
			name:"深红",
			num:"004002"
		},{
			name:"大红",
			num:"004003"
		},{
			name:"橘红",
			num:"004004"
		},{
			name:"粉红",
			num:"004005"
		},{
			name:"酒红",
			num:"004006"
		},{
			name:"西瓜红",
			num:"004007"
		},{
			name:"藕色",
			num:"004008"
		},{
			name:"姨妈红",
			num:"004009"
		}]
	},{
		name:"黄色系",
		num:"005",
		child:[{
			name:"黄色",
			num:"005001"
		}]
	},{
		name:"绿色系",
		num:"006",
		child:[{
			name:"绿色",
			num:"006001"
		}]
	}],
	cicun:[{
		name:"50ml",
		cc:50,
	},{
		name:"100ml",
		cc:100,
	},{
		name:"125ml",
		cc:125,
	},{
		name:"250ml",
		cc:250,
	},{
		name:"500ml",
		cc:500,
	},{
		name:"1L",
		cc:1000,
	}]
}
var htmls = new Htmlrendering({
	id:"htmls",
	mors:mors,
})
htmls.init()
htmls.comeback = function(){
		
}