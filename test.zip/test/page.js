/**
 * 页码组件
 * @param obj	
 * 参数为对象，属性有：
 * id ----- string
 * allnum ------ number
 * pagenum -------number
 * tis ------ bol
 * equipartnum ------ bol
 * gopage ------ bol
 * style
 * class
 * 方法有：
 * 上一页
 * 下一页
 * 选择页
 * 跳转页
 * 重新分页
 * comeback
var npage = new Page({
 	id:"page",
 	allnum:100,
 	pagenum:10;
 })
 * ---------------------------- usage:----------------------------
 */
function Page(page){
	var obj = page;
	var that = this;
	var allpagenum = Math.ceil(obj.allnum/obj.elnum);
	
	var pages = $("#" + obj.id);
	var jbpagebox = $("<div></div>");
	jbpagebox.addClass("jbpagebox");
	pages.append(jbpagebox);
	var nowpage = 0;
	//渲染1，渲染共分四个部分，左边页码数量提示，页码选择页，分页数量选择select框，页码输入跳转框
	
	function tisrendering(){
		var tisdiv = $("<div></div>")
		tisdiv.addClass("tisdiv");
		tisdiv.html("共" + obj.allnum + "条")	
		jbpagebox.append(tisdiv)
	}
	
	//页码选择页
	function pageboxrendering(){
		var div = $("<div></div>");
		div.addClass("clickpagebtdiv");
		
		var prevpage,nextpage,ul;
		prevpage = $("<div></div>");
		prevpage.addClass("prevpage")
		prevpage.html("上一页")	
		addEventHandler(prevpage[0], 'click', clickprevli);
		
		nextpage = $("<div></div>");
		nextpage.addClass("nextpage")
		nextpage.html("下一页")
		addEventHandler(nextpage[0], 'click', clicknextli);
		
		ul = $("<ul></ul>");
		ul.addClass("clickpagebtdivul")
		
		div.append(prevpage)
		div.append(ul)
		div.append(nextpage)
		jbpagebox.append(div);
		clickpagebtdivulrending()
	}
	
	function clickpagebtdivulrending(pagenum){
		$(".clickpagebtdivul").html("");
		if(!pagenum)
			pagenum = 1;
		nowpage = pagenum	
		pagenum = Number(pagenum)
		if(pagenum<=1){
			$(".prevpage").addClass("unclick");
		}else{
			$(".prevpage").removeClass("unclick");
		}
		if(pagenum==allpagenum){
			$(".nextpage").addClass("unclick");
		}else{
			$(".nextpage").removeClass("unclick");
		}
			
		var kind;
		if(allpagenum>8){
			if(pagenum<=4){
				kind = "lponit"
			}
			if(pagenum>4){
				if((allpagenum-pagenum)>=4){
					kind = "plponit"
				}else{
					kind = "pponit"
				}
			}
			
		}
		switch(kind){
		    case "pponit":
				for(var i = 0;i<7;i++){
					var li = $("<li></li>");
					if(i==0){
						li.html(1);
					}else if(i==1){
						li.html("...");
					}else{
						li.html((allpagenum + i - 6));
						// console.log(allpagenum + i - 6)
					}
					if(pagenum == (allpagenum + i - 6)){
						li.addClass("cur")
					}
					if(li.html()!="..."){
						addEventHandler(li[0], 'click', clickli);
					}
					$(".clickpagebtdivul").append(li)
				}
		        break;		
			case "lponit":
				for(var i = 0;i<7;i++){
					var li = $("<li></li>");
					if(i==5){
						li.html("...");
					}else if(i==6){
						li.html(allpagenum);					
					}else{
						li.html((i+1));
					}
					if(pagenum == (i +1)){
						li.addClass("cur")
					}
					if(li.html()!="..."){
						addEventHandler(li[0], 'click', clickli);
					}
					$(".clickpagebtdivul").append(li)
				}
			    break;	
			case "plponit":
				for(var i = 0;i<9;i++){
					var li = $("<li></li>");
					if(i==0){
						li.html(1);
					}else if(i==1){
						li.html("...");
					}else if(i==7){
						li.html("...");
					}else if(i==8){
						li.html(allpagenum);
					}else{
						li.html((pagenum+(i-4)));
					}
					if(pagenum == (pagenum+(i-4))){
						li.addClass("cur")
					}
					if(li.html()!="..."){
						addEventHandler(li[0], 'click', clickli);
					}
					$(".clickpagebtdivul").append(li)
				}
			    break;					
		    default:
		        console.log("种类未定义默认")
				var length = allpagenum<7?allpagenum:7
				for(var i = 0;i<length;i++){
					var li = $("<li></li>");
					li.html((i+1))
					if((i+1) == pagenum){
						li.addClass("cur")
					}
					addEventHandler(li[0], 'click', clickli);
					$(".clickpagebtdivul").append(li)
				}
		}
	} 
	
	function selectelnumrendering(){
		var numarr = [5,10,20,30,40,50]
		if(obj.elnum != 5 && obj.elnum != 10 && obj.elnum != 20 && obj.elnum != 30 && obj.elnum != 40 && obj.elnum != 50){
			numarr.unshift(obj.elnum)
		}
		var elnumselect = $("<div></div>");
		elnumselect.addClass("elnumselect");
		var elnumselectinput = $("<div></div>"); 
		elnumselectinput.addClass("elnumselectinput")
		elnumselectinput.html(numarr[0]+"/条每页");
		addEventHandler(elnumselectinput[0], 'click', elnumselectinputfun);
		jbpagebox.append(elnumselect)
		elnumselect.append(elnumselectinput)
		
		var elnumselectul = $("<ul></ul>");
		elnumselectul.addClass("elnumselectul")
		elnumselectul.css({
			width:elnumselectinput[0].clientWidth + "px",
		})
		for(var i = 0;i<numarr.length;i++){
			var li = document.createElement("li");
			li.innerHTML = numarr[i] + "/条每页";
			addEventHandler(li, 'click', elnumselectullifun);
			elnumselectul.append(li)
		}	
		elnumselect.append(elnumselectul)	
	}
	
	function gopagerendering(){
		var gopagebox = $("<div></div>");
			gopagebox.addClass("gopagebox");
			jbpagebox.append(gopagebox)
			var span = $("<span></span>");
			span.html("跳转到");
			var input = $("<input>");
			input.addClass("gopageboxinput")
			input.val(nowpage);
			addEventHandler(input[0], 'input', changegopageboxinput);		
			var spant = $("<span></span>");
			spant.html("页");
			var button = $("<button></button>");
			button.addClass("gopageboxbutton")			
			button.html("确定");
			addEventHandler(button[0], 'click', clickgopageboxbutton);
			gopagebox.append(span)
			gopagebox.append(input)
			gopagebox.append(spant)
			gopagebox.append(button)
	}
	
	function clickli(){
		nowpage = this.innerText;
		clickpagebtdivulrending(this.innerText)
		if(obj.gopage==true) $(".gopageboxinput").val(nowpage)
		comeback(that.comeback,this.innerText)
	}
	function comeback(comebacks,t){
		comebacks(t)
	}
	function clickprevli(){
		if(nowpage<=1) return
		nowpage = parseInt(nowpage) - 1;
		clickpagebtdivulrending(nowpage)
		if(obj.gopage==true) $(".gopageboxinput").val(nowpage)
		comeback(that.comeback,nowpage)
	}
	function clicknextli(){
		if(nowpage >= allpagenum) return
		nowpage =  parseInt(nowpage) + 1;
		clickpagebtdivulrending(nowpage)
		if(obj.gopage==true) $(".gopageboxinput").val(nowpage)
		comeback(that.comeback,nowpage)
	}
	//
	
	function elnumselectinputfun(){
		$(this).next().show()
	}
	
	function elnumselectullifun(){
		$(this).parent().prev().html($(this).html());
		$(this).parent().hide();
		allpagenum = Math.ceil(obj.allnum/parseInt(this.innerHTML))	
		clickpagebtdivulrending();
		if(obj.gopage==true) $(".gopageboxinput").val(nowpage)
	}
	
	function changegopageboxinput(){
		console.log(this.value)
		if(this.value >= allpagenum){
			this.value = allpagenum
		}
	}
	
	function clickgopageboxbutton(){
		nowpage = $(".gopageboxinput").eq(0).val();
		clickpagebtdivulrending(nowpage)
		comeback(that.comeback,nowpage)
	}
	
	//点击页面其他层级，选择弹框隐藏
	document.addEventListener('click', function(){
		var e = e || window.event; //浏览器兼容性
		var elem = e.target || e.srcElement;
		
		//isConnected的意思是判断检查是否与节点连接上因为在页面上会做到一些页面的删除导致父节点为null；所以通过该属性做中转
		if(elem.isConnected == false){
			return
		}
		
		while (elem) { //循环判断至跟节点，防止点击的是div子元素
			if (elem.className && elem.className.indexOf("elnumselect") != -1) {
				return;
			}
			elem = elem.parentNode;
		}
		$("#" + obj.id + " .elnumselectul").hide();	
	})
	
	this.init = function(){
		if(obj.tis == true) tisrendering();
					
		pageboxrendering()
		if(obj.equipartnum == true) selectelnumrendering();
					
		if(obj.gopage == true ) gopagerendering();			
	}
	
	this.comeback = function(){
		
	};
}

// var npage = new Page({
// 	id:"page",
// 	allnum:101,
// 	elnum:2,
// 	tis:true,
// 	equipartnum:true,
// 	gopage:true,
// })
// npage.init()
// npage.comeback = function(t){
// 	console.log("当前页第" + t + "页")
// }