/**
 * 页码组件
 * @param obj	
 * 参数为对象，属性有：
 * id ----- string(必填)  
 * allnum ------ number(必填)   //数据总数
 * pagenum -------number(必填)   //每页数
 * tis ------ bol   //是否有最左变总数提示
 * equipartnum ------ bol  //是否可以重新分页
 * gopage ------ bol  、、是否有页面跳转输入
 * style
 * class
 * 方法有：
 * 上一页   
 * 下一页   clickNextLi()
 * 选择页   clickli()
 * 跳转页   clickGopageBoxButton()
 * 重新分页   elnumSelectullifun()
 * comeback
var npage = new Page({
 	id:"page",
 	allnum:100,
 	pagenum:10;
 })
 * ---------------------------- usage:----------------------------
 */
function Page(page){
	var obj = page;
	var that = this;
	var jbPageBoxnum = Math.ceil(obj.allnum/obj.elnum);
	
	var pages = $("#" + obj.id);
	var jbPageBox = $("<div></div>");
	jbPageBox.addClass("jb-page-box");
	pages.append(jbPageBox);
	var nowpage = 0;
	//渲染1，渲染共分四个部分，左边页码数量提示，页码选择页，分页数量选择select框，页码输入跳转框
	
	function tisRendering(){
		var tisdiv = $("<div></div>")
		tisdiv.addClass("tisdiv");
		tisdiv.html("共" + obj.allnum + "条")	
		jbPageBox.append(tisdiv)
	}
	
	//页码选择页
	function pageBoxRendering(){
		var div = $("<div></div>");
		div.addClass("click-page-bt-div");
		
		var prevpage,nextpage,ul;
		prevpage = $("<div></div>");
		prevpage.addClass("prevpage")
		prevpage.html("上一页")	
		addEventHandler(prevpage[0], 'click', clickPageBtdiv);
		
		nextpage = $("<div></div>");
		nextpage.addClass("nextpage")
		nextpage.html("下一页")
		addEventHandler(nextpage[0], 'click', clickNextLi);
		
		ul = $("<ul></ul>");
		ul.addClass("click-page-bt-div-ul")
		
		div.append(prevpage)
		div.append(ul)
		div.append(nextpage)
		jbPageBox.append(div);
		clickPageBtdivUlRending()
	}
	
	function clickPageBtdivUlRending(pagenum){
		$(".click-page-bt-div-ul").html("");
		if(!pagenum)
			pagenum = 1;
		nowpage = pagenum	
		pagenum = Number(pagenum)
		if(pagenum<=1){
			$(".prevpage").addClass("unclick");
		}else{
			$(".prevpage").removeClass("unclick");
		}
		if(pagenum==jbPageBoxnum){
			$(".nextpage").addClass("unclick");
		}else{
			$(".nextpage").removeClass("unclick");
		}
			
		var kind;
		if(jbPageBoxnum>8){
			if(pagenum<=4){
				kind = "lponit"
			}
			if(pagenum>4){
				if((jbPageBoxnum-pagenum)>=4){
					kind = "plponit"
				}else{
					kind = "pponit"
				}
			}			
		}
		console.log(kind)
		switch(kind){
		    case "pponit":
				for(var i = 0;i<7;i++){
					var li = $("<li></li>");
					if(i==0){
						li.html(1);
					}else if(i==1){
						li.html("...");
					}else{
						li.html((jbPageBoxnum + i - 6));
						// console.log(jbPageBox + i - 6)
					}
					if(pagenum == (jbPageBoxnum + i - 6)){
						li.addClass("cur")
					}
					if(li.html()!="..."){
						addEventHandler(li[0], 'click', clickli);
					}
					$(".click-page-bt-div-ul").append(li)
				}
		        break;		
			case "lponit":
				for(var i = 0;i<7;i++){
					var li = $("<li></li>");
					if(i==5){
						li.html("...");
					}else if(i==6){
						li.html(jbPageBoxnum);					
					}else{
						li.html((i+1));
					}
					if(pagenum == (i +1)){
						li.addClass("cur")
					}
					if(li.html()!="..."){
						addEventHandler(li[0], 'click', clickli);
					}
					$(".click-page-bt-div-ul").append(li)
				}
			    break;	
			case "plponit":
				for(var i = 0;i<9;i++){
					var li = $("<li></li>");
					if(i==0){
						li.html(1);
					}else if(i==1){
						li.html("...");
					}else if(i==7){
						li.html("...");
					}else if(i==8){
						li.html(jbPageBoxnum);
					}else{
						li.html((pagenum+(i-4)));
					}
					if(pagenum == (pagenum+(i-4))){
						li.addClass("cur")
					}
					if(li.html()!="..."){
						addEventHandler(li[0], 'click', clickli);
					}
					$(".click-page-bt-div-ul").append(li)
				}
			    break;					
		    default:
		        console.log("种类未定义默认")
				var length = jbPageBoxnum<7?jbPageBoxnum:7
				for(var i = 0;i<length;i++){
					var li = $("<li></li>");
					li.html((i+1))
					if((i+1) == pagenum){
						li.addClass("cur")
					}
					addEventHandler(li[0], 'click', clickli);
					$(".click-page-bt-div-ul").append(li)
				}
		}
	} 
	
	function selectElnumRendering(){
		var numarr = [5,10,20,30,40,50]
		if(obj.elnum != 5 && obj.elnum != 10 && obj.elnum != 20 && obj.elnum != 30 && obj.elnum != 40 && obj.elnum != 50){
			numarr.unshift(obj.elnum)
		}
		var elnumSelect = $("<div></div>");
		elnumSelect.addClass("elnum-select");
		var elnumSelectInput = $("<div></div>"); 
		elnumSelectInput.addClass("elnum-select-input")
		elnumSelectInput.html(numarr[0]+"/条每页");
		addEventHandler(elnumSelectInput[0], 'click', elnumSelectInputFun);
		jbPageBox.append(elnumSelect)
		elnumSelect.append(elnumSelectInput)
		
		var elnumSelectul = $("<ul></ul>");
		elnumSelectul.addClass("elnum-select-ul")
		elnumSelectul.css({
			width:elnumSelectInput[0].clientWidth + "px",
		})
		for(var i = 0;i<numarr.length;i++){
			var li = document.createElement("li");
			li.innerHTML = numarr[i] + "/条每页";
			addEventHandler(li, 'click', elnumSelectullifun);
			elnumSelectul.append(li)
		}	
		elnumSelect.append(elnumSelectul)	
	}
	
	function gopageRendering(){
		var gopageBox = $("<div></div>");
			gopageBox.addClass("gopage-box");
			jbPageBox.append(gopageBox)
			var span = $("<span></span>");
			span.html("跳转到");
			var input = $("<input>");
			input.addClass("gopage-box-input")
			input.val(nowpage);
			addEventHandler(input[0], 'input', changeGopageBoxInput);		
			var spant = $("<span></span>");
			spant.html("页");
			var button = $("<button></button>");
			button.addClass("gopage-box-button")			
			button.html("确定");
			addEventHandler(button[0], 'click', clickGopageBoxButton);
			gopageBox.append(span)
			gopageBox.append(input)
			gopageBox.append(spant)
			gopageBox.append(button)
	}
	
	function clickli(){
		nowpage = this.innerText;
		clickPageBtdivUlRending(this.innerText)
		if(obj.gopage==true) $(".gopage-box-input").val(nowpage)
		comeback(that.comeback,this.innerText)
	}
	function comeback(comebacks,t){
		comebacks(t)
	}
	function clickPageBtdiv(){
		if(nowpage<=1) return
		nowpage = parseInt(nowpage) - 1;
		clickPageBtdivUlRending(nowpage)
		if(obj.gopage==true) $(".gopage-box-input").val(nowpage)
		comeback(that.comeback,nowpage)
	}
	function clickNextLi(){
		if(nowpage >= jbPageBoxnum) return
		nowpage =  parseInt(nowpage) + 1;
		clickPageBtdivUlRending(nowpage)
		if(obj.gopage==true) $(".gopage-box-input").val(nowpage)
		comeback(that.comeback,nowpage)
	}
	//
	
	function elnumSelectInputFun(){
		$(this).next().show()
	}
	
	function elnumSelectullifun(){
		$(this).parent().prev().html($(this).html());
		$(this).parent().hide();
		jbPageBoxnum = Math.ceil(obj.allnum/parseInt(this.innerHTML))	
		clickPageBtdivUlRending();
		if(obj.gopage==true) $(".gopage-box-input").val(nowpage)
	}
	
	function changeGopageBoxInput(){
		console.log(this.value)
		if(this.value >= jbPageBoxnum){
			this.value = jbPageBoxnum
		}
	}
	
	function clickGopageBoxButton(){
		nowpage = $(".gopage-box-input").eq(0).val();
		clickPageBtdivUlRending(nowpage)
		comeback(that.comeback,nowpage)
	}
	
	//点击页面其他层级，选择弹框隐藏
	document.addEventListener('click', function(){
		var e = e || window.event; //浏览器兼容性
		var elem = e.target || e.srcElement;
		
		//isConnected的意思是判断检查是否与节点连接上因为在页面上会做到一些页面的删除导致父节点为null；所以通过该属性做中转
		if(elem.isConnected == false){
			return
		}
		
		while (elem) { //循环判断至跟节点，防止点击的是div子元素
			if (elem.className && elem.className.indexOf("elnum-select") != -1) {
				return;
			}
			elem = elem.parentNode;
		}
		$("#" + obj.id + " .elnum-select-ul").hide();	
	})
	
	this.init = function(){
		if(obj.tis == true) tisRendering();
					
		pageBoxRendering()
		if(obj.equipartnum == true) selectElnumRendering();
					
		if(obj.gopage == true ) gopageRendering();			
	}
	
	this.comeback = function(){
		
	};
}

// var npage = new Page({
// 	id:"page",
// 	allnum:101,
// 	elnum:2,
// 	tis:true,
// 	equipartnum:true,
// 	gopage:true,
// })
// npage.init()
// npage.comeback = function(t){
// 	console.log("当前页第" + t + "页")
// }