/**
 *pageNav(页码导航)函数实现了分页导航栏的效果，根据页数自动生成导航栏页码，可以设置显示的最大页码数。
 * 参数分别是元素ID、数据源、最大页码数。
 * @param element：模块的外层id值。
 *  类型：字符串，不用加#号
 * @param data：数据源。
 *  类型:Json
 * @param maxPageNum:最大页码数。
 *  类型：大于等于7的数值
 *  原因：页码必须有首页和末页一共2个,以及前后两个省略号一共2个,用于表示前一页后一页以及当前页一共3个页码数。
 *        所以最少应该有7个页码数.
 *
 */
function pageNav(element,data,maxPageNum) {
    //设置默认最大页码为10
    if (!maxPageNum){
        maxPageNum = 10;
    }
    //------定义对象
    var paging = jQuery("#" + element);//模块对象
    var navUl = paging.children().eq(1);//导航ul
    var prevBtn = paging.children().first();//上一页按钮
    var nextBtn = paging.children().last();//下一页按钮
    //-------定义变量
    var pageNum = data.length;//总页数
    var pageBtnLis;//生成的li的集合
    var i,j;
    var clickNum = 1;//点击的页数，默认页码1
    var maxPageNum = maxPageNum;//最大页码数
    var median = Math.floor((maxPageNum / 2));//最大页码中间数
    // -------定义函数
    //左右箭头的点击函数
    function prevBtnClick() {
        for (i=0;i<pageBtnLis.length;i++){
            if (pageBtnLis.eq(i).children().first().hasClass("option")){
                var prevIndex = pageBtnLis.eq(i).index() - 1;
                pageBtnLis.eq(prevIndex).children().first().click();
            }else{
                //不满足条件无动作
            }
        }
    }
    function nextBtnClick() {
        for (i=0;i<pageBtnLis.length;i++){
            if (pageBtnLis.eq(i).children().first().hasClass("option")){
                var nextIndex = pageBtnLis.eq(i).index() + 1;
                pageBtnLis.eq(nextIndex).children().first().click();
                break;
            }else{
                //不满足条件无动作
            }
        }
    }
    //页码的点击函数
    function liClick() {
        var lisLength = pageBtnLis.length;//页码按钮数量
        clickNum = parseInt(jQuery(this).text());//点击的页码按钮的数字
        //清空所有页码的选中效果
        pageBtnLis.children().removeClass("option");
        //触发a的跳转动作。
        this.click();
        //判断添加左右箭头的disabled属性
        //这样写解决了点击首页再点击末页出现两个按钮都disabled的情况
        if (clickNum === 1){
            prevBtn.addClass("disabled").unbind();
            nextBtn.unbind().click(nextBtnClick).removeClass("disabled");
        }else if (clickNum === pageNum){
            nextBtn.addClass("disabled").unbind();
            prevBtn.unbind().click(prevBtnClick).removeClass("disabled");
        } else{
            prevBtn.removeClass("disabled").unbind().click(prevBtnClick);
            nextBtn.removeClass("disabled").unbind().click(nextBtnClick);
        }
        //每次点击判断点击的页数
        //点击事件也分为两种情况
        if (pageNum > maxPageNum){
            //页码数过多情况下运行
            //点击情况有三种，
            // 1、点击的数值小于li数的一半，
            // 2、点击的数值大于li数的一半并且小于总页数的后半段。
            // 3、点击的数值大于总页数的后半段。
            if (clickNum <= median){
                //点击数为最大页码的前半段时
                //所有li设置innerText和href属性。最后一个li设置为末页。倒数第二个li设置为三个点
                for (i=0;i<lisLength;i++){
                    if (i === 1){
                        pageBtnLis.eq(1).html("<a></a>").children().text(i + 1).attr("href",data[i]["src"]);
                    }else if (i === maxPageNum-1){
                        pageBtnLis.eq(i).children().text(pageNum).attr("href",data[pageNum-1]["src"]);
                    }else if (i === maxPageNum -2){
                        pageBtnLis.eq(i).html("...").removeAttr("href");
                    }else {
                        pageBtnLis.eq(i).children().text(i + 1).attr("href",data[i]["src"]);
                    }
                }
                //为第二个li设置点击事件，解决点击其他页码再点击首页第二页码由...变为2但是没有点击事件的问题。
                pageBtnLis.eq(1).children().click(liClick);
                pageBtnLis.eq(clickNum - 1).children().addClass("option");
            }else if ( clickNum>median && clickNum < pageNum - median){
                //点击的数大于li前半段且小于总页数后半段之间
                //正数第二和倒数第二变为...取消他的点击事件
                pageBtnLis.eq(1).html("...");
                pageBtnLis.eq(maxPageNum - 2).html("...");
                pageBtnLis.eq(median).children().addClass("option");
                for (i=2;i<maxPageNum;i++){
                    //i取2是从第3个li开始的意思
                    if (i< median){
                        //前半段所有li
                        var num = clickNum- median + i;//页码数字
                        pageBtnLis.eq(i).children().text(num).attr("href",data[num-1]["src"]);
                    }else if (i>= median && i < maxPageNum-2){
                        //后半段所有li
                        var num = clickNum+ i- median;
                        pageBtnLis.eq(i).children().text(num).attr("href",data[num-1]["src"]);
                    }
                }
            }else if (clickNum>= pageNum - median ){
                //点击的数大于总页数后半段。
                for (i=1;i<maxPageNum;i++){
                    //从第2个li开始重新加载
                    //让li与pageInfo相对应，倒数的每一个text相等。pageNumlis中的倒数第一位等于pageInfo的倒数第一以此类推。
                    var aText = data[pageNum-(maxPageNum-i)]["pageNum"];
                    if (i === 1){
                        //解决直接点击末页第2个页码按钮不是...的问题
                        pageBtnLis.eq(i).html("...");
                    }else if (i === maxPageNum -2 && !pageBtnLis.eq(i).children()[0]){
                        //倒数第二位不再是。。。为其注册点击事件；
                        pageBtnLis.eq(i).html("<a></a>").children().text(aText).attr("href",data[aText-1]["src"]).click(liClick);
                    }else{
                        pageBtnLis.eq(i).children().text(aText).attr("href",data[aText-1]["src"]);
                        if (parseInt(pageBtnLis.eq(i).children().text()) === clickNum){
                            pageBtnLis.eq(i).children().addClass("option");
                        }
                    }
                }
            }
        }else {
            //页码数较少情况下运行
            jQuery(this).addClass("option");
        }
    }
    // 初始化函数，生成页码，给页码和上下一页按钮注册点击事件。
    function initialize() {
        nextBtn.click(nextBtnClick);
        //initialize 初始化分为两种情况，
        if (pageNum > maxPageNum){
            //页码数多于最大页码数情况下的初始化
            for (i=0;i<maxPageNum;i++){
                if (i === maxPageNum-2){
                    //倒数第二个li
                    var li =jQuery("<li></li>").text("...");
                    navUl.append(li);
                }else if (i === maxPageNum-1){
                    //最后一个li
                    var liLast = jQuery("<li></li>");
                    var a = jQuery("<a></a>").text(pageNum).attr("href",data[pageNum-1]["src"]).click(liClick);
                    liLast.append(a);
                    navUl.append(liLast);
                } else {
                    //其余的li
                    var li = jQuery("<li></li>");
                    var a = jQuery("<a></a>").text(i+1).attr("href",data[i]["src"]).click(liClick);
                    if (i === 0){
                        a.addClass("option");
                    }
                    li.append(a);
                    //只给页码注册点击事件，
                    navUl.append(li);
                }
            }
            //默认情况上一页按钮disabled
            prevBtn.addClass("disabled");
            pageBtnLis = navUl.children() ;//生成的li的集合
        }else {
            //页码数少于或等于最大页码数的情况下的initialize 初始化。
            for (i = 0; i < pageNum; i++) {
                var li = jQuery("<li></li>");
                var a = jQuery("<a></a>").text(i + 1).attr("href",data[i]["src"]).click(liClick);
                if ( i === 0) {
                    a.addClass("option");
                }
                li.append(a);
                //只给页码注册点击事件，
                navUl.append(li);
            }
            //默认情况上一页按钮disabled
            prevBtn.addClass("disabled");
            pageBtnLis =navUl.children() ;//生成的li的集合
        }
    }
    //主体
    //设置最大页码数
    initialize();
}

var npage = new pageNav("page",100,10)