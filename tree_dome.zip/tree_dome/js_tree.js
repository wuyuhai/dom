/**
 * 树
 * @param obj	
 * 参数为对象，属性有：
	* - [必须] id：实例框的id。
	* - [必须] data：实例的节点数据为。
	* - [可选] closeIocn:收缩时节点图标,有默认值'src/add.png'
	* - [可选] openIcon:展开时节点图标,有默认值，"src/jian.png"
	* - [可选] nodeIcon: 节点内容图标 默认所有节点 可以不传，暂时默认为：“src/1.png”
	* - [可选] cilckType: 选择的类型，两种 "radio"单选中时，"checked"复习中时 不传默认单独选中"radio"
	* - [可选] cilckCurCss: //"radio"单选节点点击选中时样式  不传默认“trees-li-div-spancur”,
	* - [可选] checkedIcon: 当选择样式为'checkbox',勾选中的图标 默认为“src/hadseck” 
	* - [可选] disCheckedIcon:,当选择样式为'checkbox',没勾选中的图标 默认为“src/noseck” 
	* 注 ： 默认图片样式根据实际路径显示
 * var treedata = [{  data数据样式
		id:'1',	//节点ID									
		text:'根节点',	//节点字段				
		pid:'',//节点父ID
		nodeIcon:"src/2.png",//节点图标，没有默认跟所有节点图标相同
		child:[{
			id:'2',																								
			text:'根节点',						
			pid:'1',
			nodeIcon:"src/3.png",
			child:[{
				id:'3',																												
				text:'根节点',						
				pid:'2',
				child:[{
					id:'4',																																
					text:'根节点',							
					pid:'3',
				}]
			}],
		}]	
	}]
var myTree = new Jb_tree({
	id:"myTree",//id 必传
	data:treedata,//treedata 必传
	closeIocn:'src/dleft.png',//有默认值，可以不传					
	openIcon:'src/dright.png',//有默认值，可以不传
	nodeIcon:"src/1.png",//节点图标 默认所有节点 可以不传，暂时默认为：“src/1.png”
	cilckType:'checkbox',//选择的类型，两种 "radio"单选中时，"checked"复习中时 不传默认单独选中"radio"
	cilckCurCss:'trees-li-div-spancur',//节点点击选中时样式  不传默认“trees-li-div-spancur”,
	checkedIcon:"src/hadseck.png",//当点击样式为'checkbox',可传样式，勾选中的图标 默认为“src/hadseck”  可以不传
	disCheckedIcon:"src/noseck.png",//当点击样式为'checkbox',可传样式，没勾选中的图标 默认为“src/noseck”  可以不传
})
$("#treeEdit").click(function(){ 
	myTree.edit() //外部按钮编辑节点
})
$("#treeEditHide").click(function(){
	myTree.hideEdit()  //外部按钮隐藏编辑节点
})
$("#saveJson").click(function(){
	myTree.saveJson()   //外部按钮保存JSON格式数据
})
$("#saveXml").click(function(){
	myTree.saveXml()   //外部按钮保存XML格式数据  暂时为写
})
$("#onShowAll").click(function(){
	myTree.onShowAll()   //外部按钮展开所有按钮
})
$("#shrinkageAll").click(function(){
	myTree.shrinkageAll()  //外部按钮收缩所有按钮
})
								
myTree.removeLiCameBack = function(item){
	console.log("要删除的node",item)  //编辑节点时删除按钮点击触发的回调
}
myTree.editLiCameBack = function(item){
	console.log("要编辑的node",item)  //编辑节点时编辑按钮点击触发的回调
}
myTree.clickNodeCameBack = function(item){
	console.log("当前点击的node",item)   //radio单选时点击最底层触发的回调
}
myTree.checkboxNodeCameBack = function(node,hadcheckeddata){
	console.log('当前节点',node)     //checkbox复选时勾选和取消复选框触发的回调
	console.log('所有选中的node',hadcheckeddata)
}

 * ---------------------------- usage:----------------------------
 */

function Jb_tree(obj) {
	var obj = obj;
	var that = this;

	var closeIocn = obj.closeIocn ? obj.closeIocn : "src/add.png";
	var openIcon = obj.openIcon ? obj.openIcon : "src/jian.png";
	var cilckCurCss = obj.cilckCurCss ? obj.cilckCurCss : "trees-li-div-spancur";
	var nodeIcon = obj.nodeIcon ? obj.nodeIcon : "src/1.png";
	var cilckType = obj.cilckType ? obj.cilckType : "radio";
	var checkedIcon = obj.checkedIcon ? obj.checkedIcon : "src/hadseck.png";
	var disCheckedIcon = obj.disCheckedIcon ? obj.disCheckedIcon : "src/noseck.png";

	var trees = $("#" + obj.id);
	var treesBox = $("<div></div>");
	treesBox.addClass("trees-box")

	trees.append(treesBox)

	//渲染ul框
	function ulRendering(pul, data, kind) {
		var treesLine = $("<div></div>");
		treesLine.addClass("trees-line")
		pul.append(treesLine)

		var treesUl = $("<ul></ul>");
		treesUl.addClass("trees-ul")
		pul.append(treesUl)
		//渲染li
		if (kind) {
			liRendering(treesUl, data, treesLine, kind)
		} else {
			liRendering(treesUl, data, treesLine)
		}
	}

	function liRendering(pul, lis, line, kind) {
		for (var i = 0; i < lis.length; i++) {
			var treesLI = $("<li></li>");
			treesLI.addClass("trees-li");

			treesLI.attr("data-id", lis[i].id)
			treesLI.attr("data-text", lis[i].text)
			treesLI.attr("data-pid", lis[i].pid)
			if (lis[i].nodeIcon) {
				treesLI.attr("data-nodeIcon", lis[i].nodeIcon)
			}

			//扩展参数存储节点
			// treesLI.attr("data-iocn",lis[i].iocn)
			// treesLI.attr("data-openIcon",lis[i].openIcon)
			// treesLI.attr("data-inputType",lis[i].inputType)
			// treesLI.attr("data-inputCss",lis[i].inputCss)			
			// treesLI.attr("data-action",lis[i].action)

			if (pul.parent()[0].className.indexOf("trees-box") != -1) {
				treesLI.show()
			} else {
				treesLI.hide()
			}
			if (kind == "add") {
				treesLI.show()
			}
			var treesLiDiv = $("<div></div>");
			treesLiDiv.addClass("trees-li-div");

			var treesLiDivBox = $("<div></div>");
			treesLiDivBox.addClass("trees-li-div-box")

			var anShrinkageimg = $("<img />");
			anShrinkageimg.attr("src", closeIocn)
			treesLiDivBox.append(anShrinkageimg)
			addEventHandler(anShrinkageimg[0], "click", anShow)

			var treesLiDivImg = $("<img />");
			treesLiDivImg.addClass("trees-li-div-img")
			if (lis[i].nodeIcon) {
				treesLiDivImg.attr("src", lis[i].nodeIcon)
			} else {
				treesLiDivImg.attr("src", nodeIcon)
			}

			var treesLiDivSpan = $("<span></span>");
			treesLiDivSpan.addClass("trees-li-div-span")
			treesLiDivSpan.html(lis[i].text)


			var treesLiDivInput = $("<input />");
			treesLiDivInput.addClass("trees-li-div-input")
			treesLiDivInput.val(lis[i].text)
			addEventHandler(treesLiDivInput[0], "input", changeInputVal)

			if (cilckType == "checkbox") {
				var treesLiDivCheck = $("<div></div>");
				treesLiDivCheck.addClass("trees-li-div-check")
				treesLiDiv.append(treesLiDivCheck)

				var anCheckedImg = $("<img />");
				anCheckedImg.attr("src", disCheckedIcon)
				treesLiDivCheck.append(anCheckedImg)
				addEventHandler(anCheckedImg[0], "click", anCheckedFun)

				treesLiDivImg.addClass("trees-li-div-check-img")
				treesLiDivSpan.addClass("trees-li-div-check-span")
				treesLiDivInput.addClass("trees-li-div-check-input")
			} else {
				if (lis[i].child) {
					if (lis[i].child.length == 0) {
						addEventHandler(treesLiDivSpan[0], "click", clickNode)
					}
				} else {
					addEventHandler(treesLiDivSpan[0], "click", clickNode)
				}
			}

			treesLiDiv.append(treesLiDivImg)
			treesLiDiv.append(treesLiDivSpan)
			treesLiDiv.append(treesLiDivInput)

			var treesLiDivEdit = $("<div></div>");
			treesLiDivEdit.addClass("trees-li-div-edit")

			var liAddChild = $("<div>添加子分类</div>");
			addEventHandler(liAddChild[0], "click", addChild)

			var liPrevTopNode = $("<div>上移</div>");
			liPrevTopNode.addClass("li-prev-top")
			addEventHandler(liPrevTopNode[0], "click", liPrevTop)

			var liNextBottomNode = $("<div>下移</div>");
			liNextBottomNode.addClass("li-next-bottom")
			addEventHandler(liNextBottomNode[0], "click", liNextBottom)
			var liRemove = $("<div>删除</div>");
			addEventHandler(liRemove[0], "click", removeLi)
			if (pul.parent()[0].className.indexOf("trees-box") != -1) {
				liRemove.addClass("nocur")
			}
			var liedit = $("<div>编辑详细</div>");
			addEventHandler(liedit[0], "click", editDetail)

			treesLiDivEdit.append(liAddChild)
			treesLiDivEdit.append(liPrevTopNode)
			treesLiDivEdit.append(liNextBottomNode)
			treesLiDivEdit.append(liRemove)
			treesLiDivEdit.append(liedit)

			treesLiDiv.append(treesLiDivEdit)
			treesLI.append(treesLiDiv)
			pul.append(treesLI);
			if (lis[i].child) {
				treesLiDiv.append(treesLiDivBox)
				if (lis[i].child.length > 0) {
					ulRendering(treesLI, lis[i].child)
				}
			}
		}
		line.css({
			height: pul[0].clientHeight - 16,
		})
		lineHeight()
	}

	//下级展开
	function anShow() {
		$(this).parent().parent().siblings().show();
		$(this).parent().parent().siblings(".trees-ul").children().show()
		lineHeight()
		var anShrinkageimg = $("<img />");
		anShrinkageimg.attr("src", openIcon)
		addEventHandler(anShrinkageimg[0], "click", shrinkage)
		$(this).parent().append(anShrinkageimg)
		$(this).remove()
	}
	//下级收缩
	function shrinkage() {
		$(this).parent().parent().siblings().hide();
		$(this).parent().parent().siblings(".trees-ul").children().hide()
		lineHeight()
		var anShrinkageimg = $("<img />");
		anShrinkageimg.attr("src", closeIocn)
		addEventHandler(anShrinkageimg[0], "click", anShow)
		$(this).parent().append(anShrinkageimg)
		$(this).remove()
	}
	//计量线的高度和计算编辑按钮样式
	function lineHeight() {
		var treesLines = $(".trees-line");
		treesLines.each(function(idx, item) {
			$(item).css({
				height: $(item).next()[0].clientHeight - 16,
			})
		})

		var liPrevTops = $(".li-prev-top");
		liPrevTops.removeClass("nocur")
		liPrevTops.each(function(idx, item) {
			if ($(item).parent().parent().parent().prev().length == 0) {
				$(item).addClass("nocur")
			}
		})

		var liNextBottoms = $(".li-next-bottom");
		liNextBottoms.removeClass("nocur")
		liNextBottoms.each(function(idx, item) {
			if ($(item).parent().parent().parent().next().length == 0) {
				$(item).addClass("nocur")
			}
		})
	}

	function changeInputVal() {
		console.log(this.value)
		$(this).prev().html($(this).val())
		$(this).parent().parent().attr("data-text", $(this).val())
	}
	//点击选中状态
	function clickNode() {
		$(".trees-li-div-span").removeClass(cilckCurCss)
		$(this).addClass(cilckCurCss)
		that.clickNodeCameBack($(this).parent().parent())
	}

	//添加子分类
	function addChild() {
		if ($(this).parent().siblings(".trees-li-div-box").length == 0) {
			var treesLiDivBoxs = $("<div></div>");
			treesLiDivBoxs.addClass("trees-li-div-box")
			var anShrinkageimgs = $("<img />");
			anShrinkageimgs.attr("src", openIcon)
			treesLiDivBoxs.append(anShrinkageimgs)
			addEventHandler(anShrinkageimgs[0], "click", shrinkage)
			$(this).parent().parent().append(treesLiDivBoxs)
		}
		var data = [{
			id: '',
			text: '',
			pid: $(this).parent().parent().parent().attr("data-id"),
		}];
		var pul = $(this).parent().parent().siblings(".trees-ul")
		if (pul.length == 0) {
			pul = $(this).parent().parent().parent();
			ulRendering(pul, data, "add")
		} else {
			liRendering(pul, data, $(this).parent().parent().siblings(".trees-line"), "add")
		}
		$(".trees-li-div-input").show()
		$(".trees-li-div-edit").show()
		lineHeight()
	}
	//上移
	function liPrevTop() {
		if ($(this)[0].className.indexOf("nocur") != -1) {
			return
		}
		var lis = $(this).parent().parent().parent();
		lis.prev().before(lis)
		lineHeight()
	}
	//下移
	function liNextBottom() {
		if ($(this)[0].className.indexOf("nocur") != -1) {
			return
		}
		var lis = $(this).parent().parent().parent();
		lis.next().after(lis)
		lineHeight()
	}
	//删除节点
	function removeLi() {
		if ($(this)[0].className.indexOf("nocur") != -1) {
			return
		}
		that.removeLiCameBack($(this).parent().parent().parent())
	}
	//编辑详情
	function editDetail() {
		if ($(this)[0].className.indexOf("nocur") != -1) {
			return
		}
		that.editLiCameBack($(this).parent().parent().parent())
	}

	var checkeddata = [];
	//复选框选中
	function anCheckedFun() {
		$(this).parent().append(checkedRender("yes"))
		var linode = $(this).parent().parent().parent()
		var node = {
			id: linode.attr("data-id"),
			text: linode.attr("data-text"),
			pid: linode.attr("data-pid"),
		}
		if (linode.attr("data-nodeIcon")) {
			node.nodeIcon = linode.attr("data-nodeIcon")
		}
		checkeddata.push(node)
		that.checkboxNodeCameBack(linode, checkeddata)
		$(this).remove()
	}

	//复选框取消选中
	function anDisCheckedFun() {
		$(this).parent().append(checkedRender("no"))
		var linode = $(this).parent().parent().parent()
		for (var i = 0; i < checkeddata.length; i++) {
			if (checkeddata[i].id == linode.attr("data-id")) {
				checkeddata.splice(i, 1)
				that.checkboxNodeCameBack($(this).parent().parent().parent(), checkeddata)
				$(this).remove()
			}
		}
	}

	function checkedRender(kind) {
		var anCheckedImg = $("<img />");
		if (kind == "no") {
			anCheckedImg.attr("src", disCheckedIcon)
			addEventHandler(anCheckedImg[0], "click", anCheckedFun)
		} else {
			anCheckedImg.attr("src", checkedIcon)
			addEventHandler(anCheckedImg[0], "click", anDisCheckedFun)
		}
		return anCheckedImg
	}

	function init() {
		ulRendering(treesBox, obj.data)
	}

	init()

	//删除
	this.removeLiCameBack = function(li) {
		//自定义弹框提示是否删除避免误删	
	}

	//checkednode
	this.checkboxNodeCameBack = function(node, hadcheckeddata) {

	}

	//选中node
	this.clickNodeCameBack = function(li) {

	}
	//编辑li
	this.editLiCameBack = function(li) {
		//自定义弹框编辑	
	}

	//编辑
	this.edit = function() {
		$(".trees-li-div-input").show()
		$(".trees-li-div-edit").show()
	}

	//展开全部
	this.onShowAll = function() {
		$(".trees-li").show()
		$(".trees-li-div-box").html("")
		$(".trees-li-div-box").each(function(idx, item) {
			$(item).append(repearAnShrinkageimg("jian"))
		})
		lineHeight()
	}

	//收缩全部
	this.shrinkageAll = function() {
		$(".trees-li").hide();
		$(".trees-li-div-box").html("")
		$(".trees-li-div-box").each(function(idx, item) {
			$(item).append(repearAnShrinkageimg("add"))
		})
		$(".trees-box").children(".trees-ul").children().show()
		lineHeight()
	}

	function repearAnShrinkageimg(kind) {
		var anShrinkageimg = $("<img />");
		if (kind == "add") {
			anShrinkageimg.attr("src", closeIocn)
			addEventHandler(anShrinkageimg[0], "click", anShow)
		} else {
			anShrinkageimg.attr("src", openIcon)
			addEventHandler(anShrinkageimg[0], "click", shrinkage)
		}
		return anShrinkageimg
	}


	//隐藏编辑
	this.hideEdit = function() {
		$(".trees-li-div-input").hide()
		$(".trees-li-div-edit").hide()
	}

	//保存Json
	var jsonData = []
	this.saveJson = function() {
		jsonData = []
		var parentNode = $(".trees-box").children(".trees-ul");
		parentNode.children().each(function(idx, item) {
			jsonData.push(editjosn(item))
		})
		that.saveJsonCameback(jsonData)
	}
	this.saveJsonCameback = function(jsonData){
		
	}

	function editjosn(item) {
		var its = {
			id: $(item).attr("data-id"),
			text: $(item).attr("data-text"),
			pid: $(item).attr("data-pid")
		}
		if ($(item).children(".trees-ul").length != 0) {
			var pNode = $(item).children(".trees-ul");
			its.child = [];
			pNode.children().each(function(idy, items) {
				its.child.push(editjosn(items))
			})
		}
		return its
	}

	//保存xml
	this.saveXml = function() {
		console.log(2)
	}
}

//为新添加的元素节点添加点击事件
function addEventHandler(oTarget, sEventType, fnHandler) {
	if (oTarget.addEventListener) { //监听IE9，谷歌和火狐  
		oTarget.addEventListener(sEventType, fnHandler, false);
	} else if (oTarget.attachEvent) { //IE  
		oTarget.attachEvent("on" + sEventType, fnHandler);
	} else {
		oTarget["on" + sEventType] = fnHandler;
	}
}
